/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package UI;

import Classes.Admins;
import Classes.AdminSession;
import DatabaseOperation.AdminDb;
import java.awt.event.KeyEvent;
import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author user
 */
public class User extends javax.swing.JPanel {
    Admins admins;
    AdminDb adb = new AdminDb();
    AdminSession AdminSession = new AdminSession();

    /**
     * Creates new form User
     */
    public User() {
        initComponents();
        BtnEnabled(false);
        GetData();
        btn_save.setText("Save");
        //txtid.setEditable(false);
        txtid.hide();
        txtstatus_id.hide();
        txtrole_value.hide();
    }

    private void TxtEmpty() {
        txtid.setText("");
        txtname.setText("");
        txtusername.setText("");
        txtphone.setText("");
        txtpassword.setText("");
        txtaddress.setText("");
        txtstatus_id.setText("");
        txtrole_value.setText("");
        txtstatus_name.setSelectedItem("Select");
        txtrole_name.setSelectedItem("Select");
    }

    private void BtnEnabled(boolean x) {
        btn_delete.setEnabled(x);
    }
    
    //private void SearchObjectCreation()
    //{
        //admins = new Admins();
       // admins.setSearchQuery(txt_searchuser.getText());
    //}
    
    private void UserObjectCreation()
    {
        admins = new Admins();
        try{
            admins.setId(Integer.parseInt(txtid.getText()));
        } catch(Exception ex) {
            admins.setId(0);
        }
        admins.setName(txtname.getText());
        admins.setUserName(txtusername.getText());
        admins.setPhone_no(txtphone.getText());
        admins.setPassword(txtpassword.getText());
        admins.setAddress(txtaddress.getText());
        admins.setStatus(txtstatus_id.getText());
        admins.setRole(txtrole_value.getText());
    }
    
    private void searchUsers(){
        String queryTxt = txt_searchuser.getText();
        try {
            ResultSet result = adb.searchAdmin(queryTxt);
            DefaultTableModel user = new DefaultTableModel();
            String Role = null;
            
            user.addColumn("ID");
            user.addColumn("Name");
            user.addColumn("Username");
            user.addColumn("Phone Number");
            user.addColumn("Role");
            
            boolean dataFound = false;
            while (result.next()) {
                dataFound = true;
                if("admin".equals(result.getString("role"))){
                    Role = "Admin";
                }else if ("cashier".equals(result.getString("role"))) {
                    Role = "Cashier";
                }
                user.addRow(new Object[]{
                    result.getString("id"),
                    result.getString("name"),
                    result.getString("username"),
                    result.getString("phone"),
                    Role
                });
                if (dataFound) {
                    tb_user.setModel(user);
                } else {
                    // Jika tidak ada data ditemukan, kosongkan tabel
                    user.setRowCount(0);
                    tb_user.setModel(user);
                }
            }

            //sql.last();
            String count_rows = String.valueOf(tb_user.getRowCount());
            lb_count_rows.setText("Row Data : " + count_rows);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error " + e);
        }finally{
            adb.flushAll();
        }
    }
   
    private void GetData() {
        try {
            DefaultTableModel user = new DefaultTableModel();
            String Role = null;
            
            ResultSet result = adb.getAllAdmin();
            
            user.addColumn("ID");
            user.addColumn("Name");
            user.addColumn("Username");
            user.addColumn("Phone Number");
            user.addColumn("Role");
            
            boolean dataFound = false;
            while (result.next()) {
                dataFound = true;
                if("admin".equals(result.getString("role"))){
                    Role = "Admin";
                }else if ("cashier".equals(result.getString("role"))) {
                    Role = "Cashier";
                }
                user.addRow(new Object[]{
                    result.getString("id"),
                    result.getString("name"),
                    result.getString("username"),
                    result.getString("phone"),
                    Role
                });
                if (dataFound) {
                    tb_user.setModel(user);
                } else {
                    // Jika tidak ada data ditemukan, kosongkan tabel
                    user.setRowCount(0);
                    tb_user.setModel(user);
                }
            }
            
            //sql.last();
            String count_rows = String.valueOf(tb_user.getRowCount());
            lb_count_rows.setText("Row Data : " + count_rows);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error " + e);
        }
    }
    
    private void GetData_View(){
        int row = tb_user.getSelectedRow();
        String row_id = (tb_user.getModel().getValueAt(row, 0).toString());
        txtid.setText(row_id);
        BtnEnabled(true);
        if(row_id.equals(Integer.toString(AdminSession.getId()))){
            btn_delete.setEnabled(false);
        }
    }

    private void TbClick() {
        String row_id = txtid.getText();
        int adminId = Integer.parseInt(txtid.getText());
        if (!"0".equals(row_id)) {
            try {
                btn_save.setText("Edit");
                ResultSet result = adb.selectedAdminById(adminId);
                if (result.next()) {
                    //System.out.println(">>>>>>>>>> "+ result.getString("status"));
                    txtid.setText(row_id);
                    //txtid.setText(Integer.toString(result.getInt("id")));
                    txtname.setText(result.getString("name"));
                    txtusername.setText(result.getString("username"));
                    txtphone.setText(result.getString("phone"));
                    txtpassword.setText(result.getString("password"));
                    txtaddress.setText(result.getString("address"));
                    txtstatus_id.setText(result.getString("active_status"));
                    
                    if("0".equals(result.getString("active_status"))){
                        txtstatus_name.setSelectedItem("Pending");
                    }else{
                        txtstatus_name.setSelectedItem("Published");
                    }
                    
                    txtrole_value.setText(result.getString("role"));
                    
                    if("admin".equals(result.getString("role"))){
                        txtrole_name.setSelectedItem("Admin");
                    }else{
                        txtrole_name.setSelectedItem("Cashier");
                    }
                    txtname.requestFocus();
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Error " + e);
            } finally {
            adb.flushAll();
        }
        } else {
            JOptionPane.showMessageDialog(null, "Terdapat kesalahan id null!");
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txtname = new javax.swing.JTextField();
        txtusername = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtphone = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtpassword = new javax.swing.JPasswordField();
        jLabel6 = new javax.swing.JLabel();
        txtstatus_name = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        txtrole_name = new javax.swing.JComboBox<>();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtaddress = new javax.swing.JTextArea();
        btn_save = new javax.swing.JButton();
        btn_reset = new javax.swing.JButton();
        btn_cancel = new javax.swing.JButton();
        btn_delete = new javax.swing.JButton();
        txt_searchuser = new javax.swing.JTextField();
        btn_searchuser = new javax.swing.JButton();
        btn_clearsearch = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tb_user = new javax.swing.JTable();
        lb_count_rows = new javax.swing.JLabel();
        txtrole_value = new javax.swing.JTextField();
        txtstatus_id = new javax.swing.JTextField();
        txtid = new javax.swing.JTextField();

        setLayout(new java.awt.CardLayout());

        jPanel1.setBackground(new java.awt.Color(210, 218, 255));

        jLabel1.setFont(new java.awt.Font("SansSerif", 1, 24)); // NOI18N
        jLabel1.setText("Users");
        jLabel1.setMaximumSize(new java.awt.Dimension(104, 32));
        jLabel1.setMinimumSize(new java.awt.Dimension(104, 32));
        jLabel1.setPreferredSize(new java.awt.Dimension(104, 32));

        jPanel2.setMinimumSize(new java.awt.Dimension(0, 0));
        jPanel2.setPreferredSize(new java.awt.Dimension(624, 170));

        jLabel2.setText("Name :");
        jLabel2.setMaximumSize(new java.awt.Dimension(100, 16));
        jLabel2.setMinimumSize(new java.awt.Dimension(100, 16));
        jLabel2.setPreferredSize(new java.awt.Dimension(100, 16));

        txtname.setMinimumSize(new java.awt.Dimension(170, 22));
        txtname.setPreferredSize(new java.awt.Dimension(170, 22));

        txtusername.setMinimumSize(new java.awt.Dimension(170, 22));
        txtusername.setPreferredSize(new java.awt.Dimension(170, 22));

        jLabel3.setText("Username :");
        jLabel3.setMaximumSize(new java.awt.Dimension(100, 16));
        jLabel3.setMinimumSize(new java.awt.Dimension(100, 16));
        jLabel3.setPreferredSize(new java.awt.Dimension(100, 16));

        jLabel4.setText("Phone Number :");
        jLabel4.setMaximumSize(new java.awt.Dimension(100, 16));
        jLabel4.setMinimumSize(new java.awt.Dimension(100, 16));
        jLabel4.setPreferredSize(new java.awt.Dimension(100, 16));

        txtphone.setMinimumSize(new java.awt.Dimension(170, 22));
        txtphone.setPreferredSize(new java.awt.Dimension(170, 22));
        txtphone.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtphoneKeyTyped(evt);
            }
        });

        jLabel5.setText("Password :");
        jLabel5.setMaximumSize(new java.awt.Dimension(100, 16));
        jLabel5.setMinimumSize(new java.awt.Dimension(100, 16));
        jLabel5.setPreferredSize(new java.awt.Dimension(100, 16));

        txtpassword.setMinimumSize(new java.awt.Dimension(170, 22));
        txtpassword.setPreferredSize(new java.awt.Dimension(170, 22));

        jLabel6.setText("Select Status :");
        jLabel6.setMaximumSize(new java.awt.Dimension(100, 16));
        jLabel6.setMinimumSize(new java.awt.Dimension(100, 16));
        jLabel6.setPreferredSize(new java.awt.Dimension(100, 16));

        txtstatus_name.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select", "Pending", "Published" }));
        txtstatus_name.setMinimumSize(new java.awt.Dimension(170, 22));
        txtstatus_name.setPreferredSize(new java.awt.Dimension(170, 22));
        txtstatus_name.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                txtstatus_nameItemStateChanged(evt);
            }
        });

        jLabel7.setText("Select Role :");
        jLabel7.setMaximumSize(new java.awt.Dimension(100, 16));
        jLabel7.setMinimumSize(new java.awt.Dimension(100, 16));
        jLabel7.setPreferredSize(new java.awt.Dimension(100, 16));

        txtrole_name.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select", "Admin", "Cashier" }));
        txtrole_name.setMinimumSize(new java.awt.Dimension(170, 22));
        txtrole_name.setPreferredSize(new java.awt.Dimension(170, 22));
        txtrole_name.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                txtrole_nameItemStateChanged(evt);
            }
        });

        jLabel8.setText("Address :");
        jLabel8.setMaximumSize(new java.awt.Dimension(100, 16));
        jLabel8.setMinimumSize(new java.awt.Dimension(100, 16));
        jLabel8.setPreferredSize(new java.awt.Dimension(100, 16));

        txtaddress.setColumns(20);
        txtaddress.setRows(5);
        jScrollPane1.setViewportView(txtaddress);

        btn_save.setBackground(new java.awt.Color(0, 204, 0));
        btn_save.setText("Save");
        btn_save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_saveActionPerformed(evt);
            }
        });

        btn_reset.setText("Reset");
        btn_reset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_resetActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtname, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtusername, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(txtphone, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(txtrole_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtstatus_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtpassword, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(btn_save)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(btn_reset)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtusername, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtpassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(txtphone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtstatus_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtrole_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 26, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btn_save)
                            .addComponent(btn_reset))))
                .addContainerGap())
        );

        btn_cancel.setText("Cancel");
        btn_cancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cancelActionPerformed(evt);
            }
        });

        btn_delete.setBackground(new java.awt.Color(255, 0, 0));
        btn_delete.setText("Delete");
        btn_delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_deleteActionPerformed(evt);
            }
        });

        btn_searchuser.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/search.png"))); // NOI18N
        btn_searchuser.setMaximumSize(new java.awt.Dimension(22, 22));
        btn_searchuser.setMinimumSize(new java.awt.Dimension(22, 22));
        btn_searchuser.setPreferredSize(new java.awt.Dimension(22, 22));
        btn_searchuser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_searchuserActionPerformed(evt);
            }
        });

        btn_clearsearch.setBackground(new java.awt.Color(0, 204, 0));
        btn_clearsearch.setText("Clear");
        btn_clearsearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_clearsearchActionPerformed(evt);
            }
        });

        jScrollPane2.setPreferredSize(new java.awt.Dimension(624, 200));

        tb_user.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tb_user.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tb_userMouseClicked(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                tb_userMouseReleased(evt);
            }
        });
        tb_user.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tb_userKeyReleased(evt);
            }
        });
        jScrollPane2.setViewportView(tb_user);

        lb_count_rows.setText("Datacount");
        lb_count_rows.setMaximumSize(new java.awt.Dimension(100, 16));
        lb_count_rows.setMinimumSize(new java.awt.Dimension(100, 16));
        lb_count_rows.setPreferredSize(new java.awt.Dimension(100, 16));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btn_cancel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btn_delete)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txt_searchuser, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btn_searchuser, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btn_clearsearch))
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lb_count_rows, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtstatus_id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtrole_value, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_cancel)
                    .addComponent(btn_delete)
                    .addComponent(txt_searchuser, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_searchuser, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_clearsearch))
                .addGap(18, 18, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtrole_value, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txtstatus_id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txtid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(lb_count_rows, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(28, Short.MAX_VALUE))
        );

        add(jPanel1, "card2");
    }// </editor-fold>//GEN-END:initComponents

    private void btn_searchuserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_searchuserActionPerformed
        searchUsers();
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_searchuserActionPerformed

    private void txtphoneKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtphoneKeyTyped
        char c = evt.getKeyChar();
        if(!(Character.isDigit(c) || c== KeyEvent.VK_BACK_SPACE || c == KeyEvent.VK_DELETE ))
        {
            JOptionPane.showMessageDialog(null, "Input must be a number", "Illegal Input", JOptionPane.ERROR_MESSAGE);
            evt.consume();
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_txtphoneKeyTyped

    private void txtstatus_nameItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_txtstatus_nameItemStateChanged
        String status_name = txtstatus_name.getSelectedItem().toString();
        if("".equals(status_name)){
            txtstatus_id.setText("");
        }else if("Select".equals(status_name)){
            txtstatus_id.setText("");
        }else if("Pending".equals(status_name)){
            txtstatus_id.setText("0");
        }else{
            txtstatus_id.setText("1");
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_txtstatus_nameItemStateChanged

    private void txtrole_nameItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_txtrole_nameItemStateChanged
        String role_name = txtrole_name.getSelectedItem().toString();
        if("".equals(role_name)){
            txtrole_value.setText("");
        }else if("Select".equals(role_name)){
            txtrole_value.setText("");
        }else if("Admin".equals(role_name)){
            txtrole_value.setText("admin");
        }else if("Cashier".equals(role_name)){
            txtrole_value.setText("cashier");
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_txtrole_nameItemStateChanged

    private void tb_userKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tb_userKeyReleased
        GetData_View();
        // TODO add your handling code here:
    }//GEN-LAST:event_tb_userKeyReleased

    private void tb_userMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tb_userMouseClicked
        GetData_View();
        TbClick();
        // TODO add your handling code here:
    }//GEN-LAST:event_tb_userMouseClicked

    private void tb_userMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tb_userMouseReleased
        GetData_View();
        TbClick();
        // TODO add your handling code here:
    }//GEN-LAST:event_tb_userMouseReleased

    private void btn_clearsearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_clearsearchActionPerformed
        GetData();
        txtid.setText("");
        txt_searchuser.setText("");
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_clearsearchActionPerformed

    private void btn_cancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cancelActionPerformed
        tb_user.clearSelection();
        TxtEmpty();
        BtnEnabled(false);
        //barcode.setIcon(null);
        btn_save.setText("Save");
        txtname.requestFocus();
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_cancelActionPerformed

    private void btn_resetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_resetActionPerformed
        btn_cancel.doClick();
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_resetActionPerformed

    private void btn_deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_deleteActionPerformed
      int ok = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete this category?", "Confirmation", JOptionPane.OK_CANCEL_OPTION);
        if (ok == 0) {
            int adminId = Integer.parseInt(txtid.getText());
            adb.deleteAdmin(adminId);
            btn_cancel.doClick();
            GetData();
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_deleteActionPerformed

    private void btn_saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_saveActionPerformed
        String row_id = txtid.getText();
        String row_name = txtname.getText();
        String row_username = txtusername.getText();
        String row_phone = txtphone.getText();
        String row_address = txtaddress.getText();
        String row_role = txtrole_value.getText();
        String row_status = txtstatus_id.getText();
        String row_password = txtpassword.getText();
        
        if (!"".equals(row_name) && !"".equals(row_username) && !"".equals(row_phone) && !"".equals(row_address) && !"".equals(row_role) && !"".equals(row_password) && !"".equals(row_status)) {
           
            UserObjectCreation();
            if ("".equals(row_id)) {
                adb.insertAdmin(admins);
                //generate(row_txtkode);
            } else {
                adb.updateAdmin(admins);
                //btn_dapatKode.setVisible(true);
            }
            btn_reset.doClick();
            GetData();
        } else {
            JOptionPane.showMessageDialog(null, "All input field are required!.");
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_saveActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_cancel;
    private javax.swing.JButton btn_clearsearch;
    private javax.swing.JButton btn_delete;
    private javax.swing.JButton btn_reset;
    private javax.swing.JButton btn_save;
    private javax.swing.JButton btn_searchuser;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lb_count_rows;
    private javax.swing.JTable tb_user;
    private javax.swing.JTextField txt_searchuser;
    private javax.swing.JTextArea txtaddress;
    private javax.swing.JTextField txtid;
    private javax.swing.JTextField txtname;
    private javax.swing.JPasswordField txtpassword;
    private javax.swing.JTextField txtphone;
    private javax.swing.JComboBox<String> txtrole_name;
    private javax.swing.JTextField txtrole_value;
    private javax.swing.JTextField txtstatus_id;
    private javax.swing.JComboBox<String> txtstatus_name;
    private javax.swing.JTextField txtusername;
    // End of variables declaration//GEN-END:variables
}
