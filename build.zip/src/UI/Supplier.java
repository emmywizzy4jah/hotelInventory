/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package UI;

import Classes.Suppliers;
import DatabaseOperation.SupplierDb;
import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author user
 */
public class Supplier extends javax.swing.JPanel {

    Suppliers suppliers;
    SupplierDb sdb = new SupplierDb();
    ResultSet result;

    /**
     * Creates new form Supplier
     */
    public Supplier() {
        initComponents();
        GetData();
        BtnEnabled(false);
        btn_save.setText("Save");
        //txtid.setEditable(false);
        txtid.hide();
        txtstatus_id.hide();
    }

    private void TxtEmpty() {
        txtid.setText("");
        txtname.setText("");
        txtphone.setText("");
        txtstatus_id.setText("");
        txtstatus_name.setSelectedItem("Select");
    }

    private void BtnEnabled(boolean x) {
        btn_delete.setEnabled(x);
    }
    
    private void SearchObjectCreation()
    {
        suppliers = new Suppliers();
        suppliers.setSearchQuery(txt_searchsupplier.getText());
    }
    
    private void SupplierObjectCreation()
    {
        suppliers = new Suppliers();
        try{
            suppliers.setId(Integer.parseInt(txtid.getText()));
        } catch(Exception ex) {
            suppliers.setId(0);
        }
        suppliers.setName(txtname.getText());
        suppliers.setPhone(txtphone.getText());
        suppliers.setStatus(txtstatus_id.getText());
    }
    
    
    private void GetData() {
        try {
            result = sdb.GetData();
            
            DefaultTableModel supplier = new DefaultTableModel();
            supplier.addColumn("ID");
            supplier.addColumn("Name");
            supplier.addColumn("Phone");

            //category.getDataVector().removeAllElements();
            //category.fireTableDataChanged();
           // category.setRowCount(0);

            while (result.next()) {
                supplier.addRow(new Object[]{
                    result.getString("id"),
                    result.getString("supplier_name"),
                    result.getString("supplier_phone")
                });
                tb_supplier.setModel(supplier);
            }
            
            //sql.last();
            String count_rows = String.valueOf(tb_supplier.getRowCount());
            lb_count_rows.setText("Row Data : " + count_rows);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error " + e);
        }finally{
            sdb.flushAll();
        }
    }
    
    private void GetData_View(){
        int row = tb_supplier.getSelectedRow();
        String row_id = (tb_supplier.getModel().getValueAt(row, 0).toString());
        txtid.setText(row_id);
        BtnEnabled(true);
    }

    private void TbClick() {
        String row_id = txtid.getText();
        int supplierId = Integer.parseInt(txtid.getText());
        if (!"0".equals(row_id)) {
            try {
                btn_save.setText("Edit");
                result = sdb.selectedSupplierById(supplierId);
                if (result.next()) {
                    txtid.setText(row_id);
                    txtname.setText(result.getString("supplier_name"));
                    txtphone.setText(result.getString("supplier_phone"));
                    txtstatus_id.setText(result.getString("supplier_status"));
                    
                    if("0".equals(result.getString("supplier_status"))){
                        txtstatus_name.setSelectedItem("Pending");
                    }else{
                        txtstatus_name.setSelectedItem("Published");
                    }
                    txtname.requestFocus();
                }
                //txt_kode.setEditable(false);
                //btn_dapatKode.hide();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Error " + e);
            } finally {
            sdb.flushAll();
        }
        } else {
            JOptionPane.showMessageDialog(null, "Terdapat kesalahan id null!");
        }
    }
    
    private void searchSupplier() {
        SearchObjectCreation();
        try {
            result = sdb.searchSupplier(suppliers);
            
            DefaultTableModel supplier = new DefaultTableModel();
            supplier.addColumn("ID");
            supplier.addColumn("Name");
            supplier.addColumn("Phone");

            //category.getDataVector().removeAllElements();
            //category.fireTableDataChanged();
           // category.setRowCount(0);

            while (result.next()) {
                supplier.addRow(new Object[]{
                    result.getString("id"),
                    result.getString("supplier_name"),
                    result.getString("supplier_phone")
                });
                tb_supplier.setModel(supplier);
            }
            
            //sql.last();
            String count_rows = String.valueOf(tb_supplier.getRowCount());
            lb_count_rows.setText("Row Data : " + count_rows);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error " + e);
        }finally{
            sdb.flushAll();
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txtname = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtphone = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtstatus_name = new javax.swing.JComboBox<>();
        btn_save = new javax.swing.JButton();
        btn_reset = new javax.swing.JButton();
        btn_cancel = new javax.swing.JButton();
        btn_delete = new javax.swing.JButton();
        txt_searchsupplier = new javax.swing.JTextField();
        btn_searchsupplier = new javax.swing.JButton();
        btn_clearsearch = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tb_supplier = new javax.swing.JTable();
        lb_count_rows = new javax.swing.JLabel();
        txtid = new javax.swing.JTextField();
        txtstatus_id = new javax.swing.JTextField();

        setPreferredSize(new java.awt.Dimension(636, 573));
        setLayout(new java.awt.CardLayout());

        jPanel1.setBackground(new java.awt.Color(210, 218, 255));

        jLabel1.setFont(new java.awt.Font("SansSerif", 1, 24)); // NOI18N
        jLabel1.setText("Supplier");
        jLabel1.setMaximumSize(new java.awt.Dimension(104, 32));
        jLabel1.setMinimumSize(new java.awt.Dimension(104, 32));
        jLabel1.setPreferredSize(new java.awt.Dimension(104, 32));

        jPanel2.setPreferredSize(new java.awt.Dimension(624, 100));

        jLabel2.setText("Supplier Name :");
        jLabel2.setMaximumSize(new java.awt.Dimension(100, 16));
        jLabel2.setMinimumSize(new java.awt.Dimension(100, 16));
        jLabel2.setPreferredSize(new java.awt.Dimension(100, 16));

        txtname.setMinimumSize(new java.awt.Dimension(170, 22));
        txtname.setPreferredSize(new java.awt.Dimension(170, 22));

        jLabel3.setText("Supplier Phone :");
        jLabel3.setMaximumSize(new java.awt.Dimension(100, 16));
        jLabel3.setMinimumSize(new java.awt.Dimension(100, 16));
        jLabel3.setPreferredSize(new java.awt.Dimension(100, 16));

        txtphone.setMinimumSize(new java.awt.Dimension(170, 22));
        txtphone.setPreferredSize(new java.awt.Dimension(170, 22));

        jLabel4.setText("Select Status :");
        jLabel4.setMaximumSize(new java.awt.Dimension(100, 16));
        jLabel4.setMinimumSize(new java.awt.Dimension(100, 16));
        jLabel4.setPreferredSize(new java.awt.Dimension(100, 16));

        txtstatus_name.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select", "Pending", "Published" }));
        txtstatus_name.setMinimumSize(new java.awt.Dimension(170, 22));
        txtstatus_name.setPreferredSize(new java.awt.Dimension(170, 22));
        txtstatus_name.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                txtstatus_nameItemStateChanged(evt);
            }
        });

        btn_save.setBackground(new java.awt.Color(0, 204, 0));
        btn_save.setLabel("Save");
        btn_save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_saveActionPerformed(evt);
            }
        });

        btn_reset.setLabel("Reset");
        btn_reset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_resetActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(btn_save)
                        .addGap(18, 18, 18)
                        .addComponent(btn_reset)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(txtstatus_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(txtphone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtphone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtstatus_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 15, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_save)
                    .addComponent(btn_reset))
                .addContainerGap())
        );

        btn_cancel.setText("Cancel");
        btn_cancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cancelActionPerformed(evt);
            }
        });

        btn_delete.setBackground(new java.awt.Color(255, 0, 0));
        btn_delete.setForeground(new java.awt.Color(255, 255, 255));
        btn_delete.setText("Delete");
        btn_delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_deleteActionPerformed(evt);
            }
        });

        btn_searchsupplier.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/search.png"))); // NOI18N
        btn_searchsupplier.setMaximumSize(new java.awt.Dimension(22, 22));
        btn_searchsupplier.setMinimumSize(new java.awt.Dimension(22, 22));
        btn_searchsupplier.setPreferredSize(new java.awt.Dimension(22, 22));
        btn_searchsupplier.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_searchsupplierActionPerformed(evt);
            }
        });

        btn_clearsearch.setBackground(new java.awt.Color(0, 204, 0));
        btn_clearsearch.setLabel("Clear");
        btn_clearsearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_clearsearchActionPerformed(evt);
            }
        });

        jScrollPane1.setPreferredSize(new java.awt.Dimension(624, 200));

        tb_supplier.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tb_supplier.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tb_supplierMouseClicked(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                tb_supplierMouseReleased(evt);
            }
        });
        tb_supplier.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tb_supplierKeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(tb_supplier);

        lb_count_rows.setText("Datacount");
        lb_count_rows.setMaximumSize(new java.awt.Dimension(100, 16));
        lb_count_rows.setMinimumSize(new java.awt.Dimension(100, 16));
        lb_count_rows.setPreferredSize(new java.awt.Dimension(100, 16));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 636, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(btn_cancel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btn_delete)
                        .addGap(91, 91, 91)
                        .addComponent(txt_searchsupplier, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btn_searchsupplier, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btn_clearsearch))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lb_count_rows, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(txtid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(txtstatus_id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(45, 45, 45))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btn_cancel)
                        .addComponent(btn_delete)
                        .addComponent(txt_searchsupplier, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btn_searchsupplier, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btn_clearsearch))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lb_count_rows, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtstatus_id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        add(jPanel1, "card2");
    }// </editor-fold>//GEN-END:initComponents

    private void btn_searchsupplierActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_searchsupplierActionPerformed
        searchSupplier();
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_searchsupplierActionPerformed

    private void btn_clearsearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_clearsearchActionPerformed
        GetData();
        txtid.setText("");
        txt_searchsupplier.setText("");
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_clearsearchActionPerformed

    private void btn_resetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_resetActionPerformed
        btn_cancel.doClick();
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_resetActionPerformed

    private void btn_cancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cancelActionPerformed
        tb_supplier.clearSelection();
        TxtEmpty();
        BtnEnabled(false);
        //barcode.setIcon(null);
        btn_save.setText("Save");
        txtname.requestFocus();
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_cancelActionPerformed

    private void btn_deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_deleteActionPerformed
      int ok = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete this supplier?", "Confirmation", JOptionPane.OK_CANCEL_OPTION);
        if (ok == 0) {
            int supplierId = Integer.parseInt(txtid.getText());
            sdb.deleteSupplier(supplierId);
            btn_cancel.doClick();
            GetData();
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_deleteActionPerformed

    private void tb_supplierKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tb_supplierKeyReleased
        GetData_View();
        // TODO add your handling code here:
    }//GEN-LAST:event_tb_supplierKeyReleased

    private void tb_supplierMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tb_supplierMouseClicked
        GetData_View();
        TbClick();
        // TODO add your handling code here:
    }//GEN-LAST:event_tb_supplierMouseClicked

    private void tb_supplierMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tb_supplierMouseReleased
        GetData_View();
        TbClick();
        // TODO add your handling code here:
    }//GEN-LAST:event_tb_supplierMouseReleased

    private void txtstatus_nameItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_txtstatus_nameItemStateChanged
        String status_name = txtstatus_name.getSelectedItem().toString();
        if("".equals(status_name)){
            txtstatus_id.setText("");
        }else if("Pending".equals(status_name)){
            txtstatus_id.setText("0");
        }else{
            txtstatus_id.setText("1");
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_txtstatus_nameItemStateChanged

    private void btn_saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_saveActionPerformed
        String row_id = txtid.getText();
        String row_name = txtname.getText();
        String row_status = txtstatus_id.getText();

        if (!"".equals(row_name) && !"".equals(row_status)) {
            SupplierObjectCreation();
            if ("".equals(row_id)) {
                sdb.insertSupplier(suppliers);
                btn_reset.doClick();
                GetData();
                //generate(row_txtkode);
            } else {
                sdb.updateSupplier(suppliers);
                btn_reset.doClick();
                GetData();
                //btn_dapatKode.setVisible(true);
            }
        } else {
            JOptionPane.showMessageDialog(null, "All input field are required!.");
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_saveActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_cancel;
    private javax.swing.JButton btn_clearsearch;
    private javax.swing.JButton btn_delete;
    private javax.swing.JButton btn_reset;
    private javax.swing.JButton btn_save;
    private javax.swing.JButton btn_searchsupplier;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lb_count_rows;
    private javax.swing.JTable tb_supplier;
    private javax.swing.JTextField txt_searchsupplier;
    private javax.swing.JTextField txtid;
    private javax.swing.JTextField txtname;
    private javax.swing.JTextField txtphone;
    private javax.swing.JTextField txtstatus_id;
    private javax.swing.JComboBox<String> txtstatus_name;
    // End of variables declaration//GEN-END:variables
}
