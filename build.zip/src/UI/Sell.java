/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package UI;

import Classes.Products;
import DatabaseOperation.ProductDb;
import Classes.Sells;
import DatabaseOperation.SellDb;
import java.awt.event.KeyEvent;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author user
 */
public class Sell extends javax.swing.JPanel {
    Products products;
    ProductDb pdb = new ProductDb();
    Sells sells;
    SellDb ssdb = new SellDb();
    ResultSet result;

    /**
     * Creates new form Sell
     */
    public Sell() {
        initComponents();
        date();
        BtnEnabled(false);
        setEditableFalse();
        PopProductTable();
        PopProductDetailTable();
        txtproduct_id.hide();
    }
    
    private void SearchObjectCreation()
    {
        products = new Products();
        products.setSearchQuery(txt_searchproduct.getText());
    }

    private void date() {
        Date tanggal = new Date();
        SimpleDateFormat formatTanggal = new SimpleDateFormat("YYYY-MM-dd");
        txttransaction_date.setText(formatTanggal.format(tanggal));
        txttransaction_date.setEditable(false);
    }

    private void EmptyInput() {
        txtproduct_category.setText("");
        txtproduct_stock.setText("");
        txtproduct_name.setText("");
        //txtstaff_name.setText("");
        txtproduct_price.setText("");
        txtproduct_quantity.setText("");
        txtsubtotal.setText("");
        txtproduct_id.setText("");
    }

    private void setEditableFalse() {
        //txt_kodeBarang.setEditable(false);
        txtproduct_category.setEditable(false);
        //txt_merek.setEditable(false);
        txtproduct_name.setEditable(false);
        txtproduct_price.setEditable(false);
        txtsubtotal.setEditable(false);
        txt_total.setEditable(false);
        txt_grandtotal.setEditable(false);
        txtproduct_stock.setEditable(false);
        //txt_idKasir.setEditable(false);
    }

    private void BtnEnabled(boolean x) {
        btn_delete.setEnabled(x);
        btn_edit.setEnabled(x);
    }
    
    private void PopProductDetailTable(){
         DefaultTableModel prodoctdetail = new DefaultTableModel();
            prodoctdetail.addColumn("ID");
            prodoctdetail.addColumn("Product Name");
            prodoctdetail.addColumn("Available Stock");
            prodoctdetail.addColumn("Quantity");
            prodoctdetail.addColumn("Unit Price");
            prodoctdetail.addColumn("SubTotal");
            
            tb_detailproduct.setModel(prodoctdetail);
    }
    
    private void PopProductTable(){
        try {
            result = pdb.getProduct();
            
            DefaultTableModel product = new DefaultTableModel();
            product.addColumn("ID");
            product.addColumn("Product Name");
            product.addColumn("Category");
            product.addColumn("Stock");
            product.addColumn("Unit Price");

            product.getDataVector().removeAllElements();
            product.fireTableDataChanged();
            product.setRowCount(0);

            while (result.next()) {
                product.addRow(new Object[]{
                    result.getString("id"),
                    result.getString("product_name"),
                    result.getString("category_name"),
                    result.getInt("stock"),
                    result.getInt("price")
                });
                tb_product.setModel(product);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Can't get products" + e + "");
        } finally {
            pdb.flushAll();
        }
    }
      
    private void SellObjectCreation()
    {
        sells = new Sells();
            //int idTransaksi = Integer.valueOf(txt_kodeTransaksi.getText());
        sells.setDate(txttransaction_date.getText());
        sells.setTotal(Integer.parseInt(txt_total.getText()));
        sells.setDiscount(Integer.parseInt(txt_discount.getText()));
        sells.setGrandTotal(Integer.parseInt(txt_grandtotal.getText()));
        sells.setStaff(txtstaff_name.getText());
        
        sells.setTbRowCount(tb_detailproduct.getRowCount());
        sells.setTb(tb_detailproduct);
    }
    
    private void searchProduct() {
        SearchObjectCreation();
        try {
            result = pdb.searchActiveProduct(products);
            
            DefaultTableModel product = new DefaultTableModel();
            product.addColumn("ID");
            //product.addColumn("Kode Barang");
            product.addColumn("Product Name");
            product.addColumn("Category");
            //product.addColumn("merek");
            product.addColumn("Stock");
            product.addColumn("Unit Price");
            
             while (result.next()) {
                product.addRow(new Object[]{
                    result.getString("id"),
                    result.getString("product_name"),
                    result.getString("category_name"),
                    result.getInt("stock"),
                    result.getInt("price")
                });
                tb_product.setModel(product);
            }
             
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Can't search products " + e);
        } finally {
            pdb.flushAll();
        }
    }
    
    private void Total() {
        int row_count = tb_detailproduct.getRowCount();
        int total = 0;
        int subTotal;
        for (int i = 0; i < row_count; i++) {
            subTotal = Integer.parseInt(tb_detailproduct.getValueAt(i, 5).toString());
            total = total + subTotal;
        }
        txt_total.setText(Integer.valueOf(total).toString());
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txtproduct_id = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txt_searchproduct = new javax.swing.JTextField();
        btn_searchproduct = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txtproduct_name = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtproduct_quantity = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtproduct_price = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtsubtotal = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        txtstaff_name = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tb_product = new javax.swing.JTable();
        btn_clear = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        txttransaction_date = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        txtproduct_category = new javax.swing.JTextField();
        btn_reset = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        txtproduct_stock = new javax.swing.JTextField();
        btn_add = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tb_detailproduct = new javax.swing.JTable();
        btn_save = new javax.swing.JButton();
        btn_delete = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        txt_total = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        txt_discount = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        txt_grandtotal = new javax.swing.JTextField();
        btn_edit = new javax.swing.JButton();

        setLayout(new java.awt.CardLayout());

        jPanel1.setBackground(new java.awt.Color(210, 218, 255));

        jLabel1.setFont(new java.awt.Font("SansSerif", 1, 24)); // NOI18N
        jLabel1.setText("Sales");
        jLabel1.setMaximumSize(new java.awt.Dimension(104, 32));
        jLabel1.setMinimumSize(new java.awt.Dimension(104, 32));
        jLabel1.setPreferredSize(new java.awt.Dimension(104, 32));

        jLabel5.setText("Search Product :");
        jLabel5.setMaximumSize(new java.awt.Dimension(100, 16));
        jLabel5.setMinimumSize(new java.awt.Dimension(100, 16));
        jLabel5.setPreferredSize(new java.awt.Dimension(100, 16));

        txt_searchproduct.setMinimumSize(new java.awt.Dimension(200, 22));
        txt_searchproduct.setPreferredSize(new java.awt.Dimension(200, 22));

        btn_searchproduct.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/search.png"))); // NOI18N
        btn_searchproduct.setMaximumSize(new java.awt.Dimension(22, 22));
        btn_searchproduct.setMinimumSize(new java.awt.Dimension(22, 22));
        btn_searchproduct.setPreferredSize(new java.awt.Dimension(22, 22));
        btn_searchproduct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_searchproductActionPerformed(evt);
            }
        });

        jPanel2.setMinimumSize(new java.awt.Dimension(0, 0));
        jPanel2.setPreferredSize(new java.awt.Dimension(624, 242));

        jLabel2.setText("Product Name :");
        jLabel2.setMaximumSize(new java.awt.Dimension(100, 16));
        jLabel2.setMinimumSize(new java.awt.Dimension(100, 16));
        jLabel2.setPreferredSize(new java.awt.Dimension(100, 16));

        txtproduct_name.setMinimumSize(new java.awt.Dimension(170, 22));
        txtproduct_name.setPreferredSize(new java.awt.Dimension(170, 22));

        jLabel3.setText("Quantity :");
        jLabel3.setMaximumSize(new java.awt.Dimension(100, 16));
        jLabel3.setMinimumSize(new java.awt.Dimension(100, 16));
        jLabel3.setPreferredSize(new java.awt.Dimension(100, 16));

        txtproduct_quantity.setMinimumSize(new java.awt.Dimension(170, 22));
        txtproduct_quantity.setPreferredSize(new java.awt.Dimension(170, 22));
        txtproduct_quantity.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtproduct_quantityKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtproduct_quantityKeyTyped(evt);
            }
        });

        jLabel4.setText("Selling Price :");
        jLabel4.setMaximumSize(new java.awt.Dimension(100, 16));
        jLabel4.setMinimumSize(new java.awt.Dimension(100, 16));
        jLabel4.setPreferredSize(new java.awt.Dimension(100, 16));

        txtproduct_price.setMinimumSize(new java.awt.Dimension(170, 22));
        txtproduct_price.setPreferredSize(new java.awt.Dimension(170, 22));

        jLabel6.setText("SubTotal :");
        jLabel6.setMaximumSize(new java.awt.Dimension(100, 16));
        jLabel6.setMinimumSize(new java.awt.Dimension(100, 16));
        jLabel6.setPreferredSize(new java.awt.Dimension(100, 16));

        txtsubtotal.setMinimumSize(new java.awt.Dimension(170, 22));
        txtsubtotal.setPreferredSize(new java.awt.Dimension(170, 22));

        jLabel7.setText("Staff Name :");
        jLabel7.setMaximumSize(new java.awt.Dimension(100, 16));
        jLabel7.setMinimumSize(new java.awt.Dimension(100, 16));
        jLabel7.setPreferredSize(new java.awt.Dimension(100, 16));

        txtstaff_name.setMinimumSize(new java.awt.Dimension(170, 22));
        txtstaff_name.setPreferredSize(new java.awt.Dimension(170, 22));

        jScrollPane1.setPreferredSize(new java.awt.Dimension(312, 120));

        tb_product.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tb_product.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tb_productMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tb_product);

        btn_clear.setText("Clear");
        btn_clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_clearActionPerformed(evt);
            }
        });

        jLabel9.setText("Transaction Date :");
        jLabel9.setToolTipText("");
        jLabel9.setMaximumSize(new java.awt.Dimension(100, 16));
        jLabel9.setMinimumSize(new java.awt.Dimension(100, 16));
        jLabel9.setPreferredSize(new java.awt.Dimension(100, 16));

        txttransaction_date.setMinimumSize(new java.awt.Dimension(170, 22));
        txttransaction_date.setPreferredSize(new java.awt.Dimension(170, 22));

        jLabel10.setText("Product Category :");
        jLabel10.setMaximumSize(new java.awt.Dimension(100, 16));
        jLabel10.setMinimumSize(new java.awt.Dimension(100, 16));
        jLabel10.setPreferredSize(new java.awt.Dimension(100, 16));

        txtproduct_category.setMinimumSize(new java.awt.Dimension(170, 22));
        txtproduct_category.setPreferredSize(new java.awt.Dimension(170, 22));

        btn_reset.setBackground(new java.awt.Color(0, 204, 0));
        btn_reset.setText("Reset");
        btn_reset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_resetActionPerformed(evt);
            }
        });

        jLabel11.setText("Availabe Stock :");
        jLabel11.setMaximumSize(new java.awt.Dimension(100, 16));
        jLabel11.setMinimumSize(new java.awt.Dimension(100, 16));
        jLabel11.setPreferredSize(new java.awt.Dimension(100, 16));

        txtproduct_stock.setMinimumSize(new java.awt.Dimension(170, 22));
        txtproduct_stock.setPreferredSize(new java.awt.Dimension(170, 22));

        btn_add.setText("Add");
        btn_add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_addActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(txtproduct_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(txtproduct_quantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtstaff_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtproduct_price, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(txtproduct_category, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(118, 118, 118)
                        .addComponent(txtproduct_stock, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(btn_clear)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btn_reset)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btn_add)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtsubtotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txttransaction_date, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtproduct_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtproduct_quantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtproduct_price, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtstaff_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtproduct_category, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jLabel11, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(txtproduct_stock, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txttransaction_date, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 15, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btn_clear, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btn_reset)
                        .addComponent(txtsubtotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btn_add)))
                .addContainerGap())
        );

        jLabel9.getAccessibleContext().setAccessibleName("Transaction Date");

        jScrollPane2.setPreferredSize(new java.awt.Dimension(624, 120));

        tb_detailproduct.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tb_detailproduct.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tb_detailproductMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tb_detailproduct);

        btn_save.setBackground(new java.awt.Color(0, 204, 0));
        btn_save.setText("Save");
        btn_save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_saveActionPerformed(evt);
            }
        });

        btn_delete.setBackground(new java.awt.Color(255, 0, 0));
        btn_delete.setForeground(new java.awt.Color(255, 255, 255));
        btn_delete.setText("Delete");
        btn_delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_deleteActionPerformed(evt);
            }
        });

        jLabel8.setText("Total :");
        jLabel8.setMaximumSize(new java.awt.Dimension(100, 16));
        jLabel8.setMinimumSize(new java.awt.Dimension(100, 16));
        jLabel8.setPreferredSize(new java.awt.Dimension(100, 16));

        txt_total.setMinimumSize(new java.awt.Dimension(170, 22));
        txt_total.setPreferredSize(new java.awt.Dimension(170, 22));

        jLabel12.setText("Discount :");
        jLabel12.setMaximumSize(new java.awt.Dimension(100, 16));
        jLabel12.setMinimumSize(new java.awt.Dimension(100, 16));
        jLabel12.setPreferredSize(new java.awt.Dimension(100, 16));

        txt_discount.setMinimumSize(new java.awt.Dimension(170, 22));
        txt_discount.setPreferredSize(new java.awt.Dimension(170, 22));
        txt_discount.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_discountKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_discountKeyTyped(evt);
            }
        });

        jLabel13.setText("Grand Total :");
        jLabel13.setMaximumSize(new java.awt.Dimension(100, 16));
        jLabel13.setMinimumSize(new java.awt.Dimension(100, 16));
        jLabel13.setPreferredSize(new java.awt.Dimension(100, 16));

        txt_grandtotal.setMinimumSize(new java.awt.Dimension(170, 22));
        txt_grandtotal.setPreferredSize(new java.awt.Dimension(170, 22));

        btn_edit.setBackground(new java.awt.Color(0, 204, 0));
        btn_edit.setText("Edit");
        btn_edit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_editActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtproduct_id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(33, 33, 33)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txt_searchproduct, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btn_searchproduct, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(btn_save)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btn_delete)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btn_edit)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txt_discount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txt_total, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txt_grandtotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_searchproduct, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txt_searchproduct, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txtproduct_id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_total, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_save)
                    .addComponent(btn_delete)
                    .addComponent(btn_edit))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(txt_discount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_grandtotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(33, Short.MAX_VALUE))
        );

        add(jPanel1, "card2");
    }// </editor-fold>//GEN-END:initComponents

    private void tb_productMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tb_productMouseClicked
        txtproduct_id.setText(tb_product.getValueAt(tb_product.getSelectedRow(), 0).toString());
        txtproduct_name.setText(tb_product.getValueAt(tb_product.getSelectedRow(), 1).toString());
        txtproduct_category.setText(tb_product.getValueAt(tb_product.getSelectedRow(), 2).toString());
        txtproduct_stock.setText(tb_product.getValueAt(tb_product.getSelectedRow(), 3).toString());
        txtproduct_price.setText(tb_product.getValueAt(tb_product.getSelectedRow(), 4).toString());
        //txt_merek.setText(tb_product.getValueAt(tb_product.getSelectedRow(), 5).toString());

        // TODO add your handling code here:
    }//GEN-LAST:event_tb_productMouseClicked

    private void btn_searchproductActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_searchproductActionPerformed
        searchProduct();
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_searchproductActionPerformed

    private void btn_resetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_resetActionPerformed
        //txt_idKasir.setText(user.getId());
        //txt_namaKasir.setText(user.getNama());
        PopProductTable();
        //id();
        EmptyInput();
        BtnEnabled(false);
        btn_add.setEnabled(true);
        txt_total.setText("");
        //txt_uangDiterima.setText("");
        //txt_uangKembalian.setText("");
        DefaultTableModel model = (DefaultTableModel) tb_detailproduct.getModel();
        model.setRowCount(0);
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_resetActionPerformed

    private void txtproduct_quantityKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtproduct_quantityKeyTyped
        char c = evt.getKeyChar();
        if(!(Character.isDigit(c) || c== KeyEvent.VK_BACK_SPACE || c == KeyEvent.VK_DELETE ))
        {
            JOptionPane.showMessageDialog(null, "Input must be a number", "Illegal Input", JOptionPane.ERROR_MESSAGE);
            evt.consume();
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_txtproduct_quantityKeyTyped

    private void tb_detailproductMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tb_detailproductMouseClicked
        txtproduct_id.setText(tb_detailproduct.getValueAt(tb_detailproduct.getSelectedRow(), 0).toString());
        txtproduct_name.setText(tb_detailproduct.getValueAt(tb_detailproduct.getSelectedRow(), 1).toString());
        txtproduct_stock.setText(tb_detailproduct.getValueAt(tb_detailproduct.getSelectedRow(), 2).toString());
        txtproduct_quantity.setText(tb_detailproduct.getValueAt(tb_detailproduct.getSelectedRow(), 3).toString());
        txtproduct_price.setText(tb_detailproduct.getValueAt(tb_detailproduct.getSelectedRow(), 4).toString());
        txtsubtotal.setText(tb_detailproduct.getValueAt(tb_detailproduct.getSelectedRow(), 5).toString());
        
        BtnEnabled(true);
        btn_add.setEnabled(false);
// TODO add your handling code here:
    }//GEN-LAST:event_tb_detailproductMouseClicked

    private void btn_addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_addActionPerformed
        if(!"".equals(txtproduct_stock.getText()) && !"".equals(txtproduct_quantity.getText()) && !"".equals(txtsubtotal.getText())){
            DefaultTableModel prodoctdetail = (DefaultTableModel) tb_detailproduct.getModel();

            int ProductId = Integer.parseInt(txtproduct_id.getText());
            String ProductName = txtproduct_name.getText();
            int ProductStock = Integer.parseInt(txtproduct_stock.getText());
            int ProductQuantity = Integer.parseInt(txtproduct_quantity.getText());
            int ProductPrice = Integer.parseInt(txtproduct_price.getText());
            int subTotal = Integer.parseInt(txtsubtotal.getText());

            prodoctdetail.addRow(new Object[]{
                ProductId, ProductName, ProductStock, ProductQuantity, ProductPrice, subTotal
            });
            EmptyInput();
            Total();
        } else {
            JOptionPane.showMessageDialog(null, "All input field are required!.");
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_addActionPerformed

    private void txtproduct_quantityKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtproduct_quantityKeyReleased
        //int Stock = Integer.parseInt(tb_product.getValueAt(tb_product.getSelectedRow(), 4).toString());
        int quantity;
        if("".equals(txtproduct_quantity.getText())){
            quantity = 0;
        } else {
            quantity = Integer.parseInt(txtproduct_quantity.getText());
        }
        int Stock = Integer.parseInt(txtproduct_stock.getText());
        int price = Integer.parseInt(txtproduct_price.getText());
        if (quantity > Stock) {
            JOptionPane.showMessageDialog(null, "Quantity is more than Available stock");
            txtproduct_quantity.setText("");
            txtsubtotal.setText("");
        } else if ("".equals(quantity)) {
            txtproduct_quantity.setText("");
            txtsubtotal.setText("");
        }else {
            txtsubtotal.setText("" + (quantity * price) + "");
            //int subTotal = Integer.valueOf(txtsubtotal.getText());
            //txtsubtotal.setText("" + (subTotal) + "");
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_txtproduct_quantityKeyReleased

    private void btn_clearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_clearActionPerformed
        txtproduct_id.setText("");
        txtproduct_category.setText("");
        //txt_merek.setText("");
        txtproduct_name.setText("");
        txtproduct_quantity.setText("");
        txtproduct_stock.setText("");
        txtproduct_price.setText("");
        txtsubtotal.setText("");
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_clearActionPerformed

    private void txt_discountKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_discountKeyTyped
        char c = evt.getKeyChar();
        if(!(Character.isDigit(c) || c== KeyEvent.VK_BACK_SPACE || c == KeyEvent.VK_DELETE ))
        {
            JOptionPane.showMessageDialog(null, "Input must be a number", "Illegal Input", JOptionPane.ERROR_MESSAGE);
            evt.consume();
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_discountKeyTyped

    private void txt_discountKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_discountKeyReleased
        int total = Integer.parseInt(txt_total.getText());
        int discount;
        if("".equals(txt_discount.getText())){
            discount = 0;
        } else {
            discount = Integer.parseInt(txt_discount.getText());
        }
        if (total >= discount) {
            txt_grandtotal.setText(Integer.valueOf(total - discount).toString());
            //int grandtotal = Integer.valueOf(txt_grandtotal.getText());
            //txt_grandtotal.setText("" + (grandtotal) + "");
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_discountKeyReleased

    private void btn_deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_deleteActionPerformed
        DefaultTableModel detail = (DefaultTableModel) tb_detailproduct.getModel();
        int row = tb_detailproduct.getSelectedRow();
        if (row >= 0) {
            detail.removeRow(row);
            EmptyInput();
            if (tb_detailproduct.getRowCount() == 0) {
                txt_total.setText("");
                txtsubtotal.setText("");
            }
            Total();
            BtnEnabled(false);
            btn_add.setEnabled(true);
        } else {
            JOptionPane.showMessageDialog(null, "Pilih Terlebih dahulu baris yang akan diHapus");
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_deleteActionPerformed

    private void btn_saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_saveActionPerformed
        SellObjectCreation();
        ssdb.insertSell(sells);
        
            PopProductTable();
            //id();
            EmptyInput();
            txtstaff_name.setText("");
            txt_total.setText("");
            txt_discount.setText("");
            txt_grandtotal.setText("");
            DefaultTableModel model = (DefaultTableModel) tb_detailproduct.getModel();
            model.setRowCount(0);
            BtnEnabled(false);
            btn_add.setEnabled(true);
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_saveActionPerformed

    private void btn_editActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_editActionPerformed
         if(!"".equals(txtproduct_stock.getText()) && !"".equals(txtproduct_quantity.getText()) && !"".equals(txtsubtotal.getText())){
            DefaultTableModel prodoctdetail = (DefaultTableModel) tb_detailproduct.getModel();

            int ProductId = Integer.parseInt(txtproduct_id.getText());
            String ProductName = txtproduct_name.getText();
            int ProductStock = Integer.parseInt(txtproduct_stock.getText());
            int ProductQuantity = Integer.parseInt(txtproduct_quantity.getText());
            int ProductPrice = Integer.parseInt(txtproduct_price.getText());
            int subTotal = Integer.parseInt(txtsubtotal.getText());

            int row = tb_detailproduct.getSelectedRow();
            if (row >= 0) {
                prodoctdetail.removeRow(row);
                prodoctdetail.addRow(new Object[]{
                    ProductId, ProductName, ProductStock, ProductQuantity, ProductPrice, subTotal
                });
            }
            Total();
            EmptyInput();
            BtnEnabled(false);
            btn_add.setEnabled(true);
        } else {
            JOptionPane.showMessageDialog(null, "All input field are required!.");
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_editActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_add;
    private javax.swing.JButton btn_clear;
    private javax.swing.JButton btn_delete;
    private javax.swing.JButton btn_edit;
    private javax.swing.JButton btn_reset;
    private javax.swing.JButton btn_save;
    private javax.swing.JButton btn_searchproduct;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable tb_detailproduct;
    private javax.swing.JTable tb_product;
    private javax.swing.JTextField txt_discount;
    private javax.swing.JTextField txt_grandtotal;
    private javax.swing.JTextField txt_searchproduct;
    private javax.swing.JTextField txt_total;
    private javax.swing.JTextField txtproduct_category;
    private javax.swing.JTextField txtproduct_id;
    private javax.swing.JTextField txtproduct_name;
    private javax.swing.JTextField txtproduct_price;
    private javax.swing.JTextField txtproduct_quantity;
    private javax.swing.JTextField txtproduct_stock;
    private javax.swing.JTextField txtstaff_name;
    private javax.swing.JTextField txtsubtotal;
    private javax.swing.JTextField txttransaction_date;
    // End of variables declaration//GEN-END:variables
}
