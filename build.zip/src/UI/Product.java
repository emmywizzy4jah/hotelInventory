/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package UI;

//import com.barcodelib.barcode.Linear;
import java.awt.event.KeyEvent;
import Classes.Products;
import DatabaseOperation.ProductDb;
import Classes.Suppliers;
import DatabaseOperation.SupplierDb;
import Classes.Categories;
import DatabaseOperation.CategoryDb;

import java.sql.*;
import java.util.HashMap;
import java.util.Random;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ArrayList;
import javax.swing.DefaultComboBoxModel;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author user
 */
public class Product extends javax.swing.JPanel {

    Products products;
    ProductDb pdb = new ProductDb();
    Suppliers suppliers;
    SupplierDb sdb = new SupplierDb();
    Categories categories;
    CategoryDb cdb = new CategoryDb();
    //ResultSet result = null;
    /**
     * Creates new form Product
     */
    public Product() {
        initComponents();
        GetData();
        BtnEnabled(false);
        SelectCategory();
        //SelectStatus();
        SelectSupplier();
        btn_save.setText("Save");
        //txtid.setEditable(false);
        txtid.hide();
        txtcategory_id.hide();
        txtsupplier_id.hide();
        txtstatus_id.hide();
        //txttemp_IDsupplier.hide();
    }

    private void SelectCategory() {
        try {
            ResultSet result = cdb.getCategories();
            txtcategory_name.addItem("Select");
            
            while (result.next()) {
                String name = result.getString("category_name");
                txtcategory_name.addItem(name);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error " + e);
        }finally{
            cdb.flushAll();
        }
    }

    private void SelectSupplier() {
        
        try {
            ResultSet result = sdb.getSuppliers();
            txtsupplier_name.addItem("Select");
            
            while (result.next()) {
                String name = result.getString("supplier_name");
                txtsupplier_name.addItem(name);   
            } 
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error " + e);
        }finally{
            sdb.flushAll();
        }
    }

    private void TxtEmpty() {
        txtid.setText("");
        //txt_kode.setText("");
        txtname.setText("");
        //txt_beli.setText("");
        //txt_jual.setText("");
        txtstock.setText("");
        txtcategory_id.setText("");
        txtstatus_id.setText("");
        txtsupplier_id.setText("");
        txtprice.setText("");
        txtcategory_name.setSelectedItem("Select");
        txtstatus_name.setSelectedItem("Select");
        txtsupplier_name.setSelectedItem("Select");
    }

    private void BtnEnabled(boolean x) {
        btn_delete.setEnabled(x);
    }
    
    private void SearchObjectCreation()
    {
        products = new Products();
        products.setSearchQuery(txt_searchproduct.getText());
    }
    
    private void ProductObjectCreation()
    {
        products = new Products();
        try{
            products.setId(Integer.parseInt(txtid.getText()));
        } catch(Exception ex) {
            products.setId(0);
        }
        products.setName(txtname.getText());
        products.setCategory(txtcategory_id.getText());
        products.setStock(txtstock.getText());
        products.setSupplier(txtsupplier_id.getText());
        products.setPrice(txtprice.getText());
        products.setStatus(txtstatus_id.getText());
        
        //products.setSearchQuery(txt_searchproduct.getText());
    }
    
    private void GetData() {
        try {
            ResultSet result = pdb.GetData();
            
            DefaultTableModel product = new DefaultTableModel();
            product.addColumn("ID");
            product.addColumn("Name");
            product.addColumn("Category");
            product.addColumn("Supplier");
            product.addColumn("Unit Price");
            product.addColumn("Stock");
            

            while (result.next()) {
                product.addRow(new Object[]{
                    result.getString("id"),
                    result.getString("product_name"),
                    result.getString("category_name"),
                    result.getString("supplier_name"),
                    result.getString("price"),
                    result.getString("stock")
                });
                tb_product.setModel(product);
            }

            //sql.last();
            String count_rows = String.valueOf(tb_product.getRowCount());
            lb_count_rows.setText("Row Data : " + count_rows);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error " + e);
        } finally {
            pdb.flushAll();
        }
    }
    
    private void GetData_View() {
        
        products = new Products();
        int row = tb_product.getSelectedRow();
        //displayToTextField(row);
        // //ObjectCreation();
        //btn_editCustomer.setEnabled(true);
        //btn_deleteCustomer.setEnabled(true);
        //btn_addCustomer.setEnabled(false);
       
        String row_id = (tb_product.getModel().getValueAt(row, 0).toString());
        txtid.setText(row_id);
        BtnEnabled(true);
    }

    private void TbClick() {
        String row_id = txtid.getText();
        int productId = Integer.parseInt(txtid.getText());
        if (!"0".equals(row_id)) {
            try {
                btn_save.setText("Edit");
                ResultSet result = pdb.selectedProductById(productId);
                if (result.next()) {
                    //System.out.println(">>>>>>>>>> "+ result.getString("status"));
                    txtid.setText(row_id);
                    //txtid.setText(Integer.toString(result.getInt("id")));
                    txtname.setText(result.getString("product_name"));
                    //txt_beli.setText(result.getString("harga_beli"));
                    txtprice.setText(result.getString("price"));
                    txtstock.setText(result.getString("stock"));
                    txtcategory_name.setSelectedItem(result.getString("category_name"));
                    txtcategory_id.setText(result.getString("category_id"));
                    //txtstatus_name.setSelectedItem(result.getString("nama_merek"));
                    txtsupplier_name.setSelectedItem(result.getString("supplier_name"));
                    txtsupplier_id.setText(result.getString("supplier_id"));
                    
                    txtstatus_id.setText(result.getString("product_status"));
                    
                    if("0".equals(result.getString("product_status"))){
                        txtstatus_name.setSelectedItem("Pending");
                    }else{
                        txtstatus_name.setSelectedItem("Published");
                    }
                            
                    //txttemp_kode.setText(kode);
                    //ImageIcon imgThisImg = new ImageIcon("src" + "/" + "img" + "/barcode/" + txt_kode.getText() + ".png");
                    //barcode.setIcon(imgThisImg);
                    txtname.requestFocus();
                }
                //txt_kode.setEditable(false);
                //btn_dapatKode.hide();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error " + e);
            } finally {
            pdb.flushAll();
        }
        } else {
            JOptionPane.showMessageDialog(null, "Terdapat kesalahan id null!");
        }
    }

    private void searchProduct() {
        SearchObjectCreation();
        try {
            ResultSet result = pdb.searchProduct(products);
            
            DefaultTableModel product = new DefaultTableModel();
            product.addColumn("ID");
            product.addColumn("Name");
            product.addColumn("Category");
            product.addColumn("Supplier");
            product.addColumn("Unit Price");
            product.addColumn("Stock");
            
            while (result.next()) {
                product.addRow(new Object[]{
                    result.getString("id"),
                    result.getString("product_name"),
                    result.getString("category_name"),
                    result.getString("supplier_name"),
                    result.getString("price"),
                    result.getString("stock")
                });
                tb_product.setModel(product);
            }

            String count_rows = String.valueOf(tb_product.getRowCount());
            lb_count_rows.setText("Row Data : " + count_rows);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error " + e);
        } finally {
            pdb.flushAll();
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txtname = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtprice = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtstock = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        txtstatus_name = new javax.swing.JComboBox<>();
        btn_save = new javax.swing.JButton();
        btn_reset = new javax.swing.JButton();
        txtcategory_name = new javax.swing.JComboBox<>();
        txtsupplier_name = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        tb_product = new javax.swing.JTable();
        txt_searchproduct = new javax.swing.JTextField();
        btn_searchproduct = new javax.swing.JButton();
        btn_clearsearch = new javax.swing.JButton();
        btn_print = new javax.swing.JButton();
        lb_count_rows = new javax.swing.JLabel();
        txtcategory_id = new javax.swing.JTextField();
        txtsupplier_id = new javax.swing.JTextField();
        txtstatus_id = new javax.swing.JTextField();
        btn_cancel = new javax.swing.JButton();
        btn_delete = new javax.swing.JButton();
        txtid = new javax.swing.JTextField();

        setMinimumSize(new java.awt.Dimension(0, 0));
        setPreferredSize(new java.awt.Dimension(636, 573));
        setLayout(new java.awt.CardLayout());

        jPanel1.setBackground(new java.awt.Color(210, 218, 255));
        jPanel1.setPreferredSize(new java.awt.Dimension(636, 573));

        jLabel1.setFont(new java.awt.Font("SansSerif", 1, 24)); // NOI18N
        jLabel1.setText("Products");

        jPanel2.setPreferredSize(new java.awt.Dimension(624, 151));

        jLabel2.setText("Product Name :");
        jLabel2.setMaximumSize(new java.awt.Dimension(100, 16));
        jLabel2.setMinimumSize(new java.awt.Dimension(100, 16));
        jLabel2.setPreferredSize(new java.awt.Dimension(100, 16));

        txtname.setMinimumSize(new java.awt.Dimension(170, 22));
        txtname.setPreferredSize(new java.awt.Dimension(170, 22));

        jLabel3.setText("Price :");
        jLabel3.setMaximumSize(new java.awt.Dimension(100, 16));
        jLabel3.setMinimumSize(new java.awt.Dimension(100, 16));
        jLabel3.setPreferredSize(new java.awt.Dimension(100, 16));

        txtprice.setMinimumSize(new java.awt.Dimension(170, 22));
        txtprice.setPreferredSize(new java.awt.Dimension(170, 22));
        txtprice.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtpriceKeyTyped(evt);
            }
        });

        jLabel4.setText("Select Category :");
        jLabel4.setMaximumSize(new java.awt.Dimension(100, 16));
        jLabel4.setMinimumSize(new java.awt.Dimension(100, 16));
        jLabel4.setPreferredSize(new java.awt.Dimension(100, 16));

        jLabel5.setText("Select Supplier :");
        jLabel5.setMaximumSize(new java.awt.Dimension(100, 16));
        jLabel5.setMinimumSize(new java.awt.Dimension(100, 16));
        jLabel5.setPreferredSize(new java.awt.Dimension(100, 16));

        jLabel6.setText("Stock :");
        jLabel6.setMaximumSize(new java.awt.Dimension(100, 16));
        jLabel6.setMinimumSize(new java.awt.Dimension(100, 16));
        jLabel6.setPreferredSize(new java.awt.Dimension(100, 16));

        txtstock.setMinimumSize(new java.awt.Dimension(170, 22));
        txtstock.setPreferredSize(new java.awt.Dimension(170, 22));
        txtstock.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtstockKeyTyped(evt);
            }
        });

        jLabel7.setText("Select Status :");
        jLabel7.setMaximumSize(new java.awt.Dimension(100, 16));
        jLabel7.setMinimumSize(new java.awt.Dimension(100, 16));
        jLabel7.setPreferredSize(new java.awt.Dimension(100, 16));

        txtstatus_name.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select", "Pending", "Published" }));
        txtstatus_name.setMinimumSize(new java.awt.Dimension(170, 22));
        txtstatus_name.setPreferredSize(new java.awt.Dimension(170, 22));
        txtstatus_name.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                txtstatus_nameItemStateChanged(evt);
            }
        });

        btn_save.setBackground(new java.awt.Color(0, 204, 0));
        btn_save.setText("Save");
        btn_save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_saveActionPerformed(evt);
            }
        });

        btn_reset.setText("Reset");
        btn_reset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_resetActionPerformed(evt);
            }
        });

        txtcategory_name.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                txtcategory_nameItemStateChanged(evt);
            }
        });

        txtsupplier_name.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                txtsupplier_nameItemStateChanged(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtname, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtstock, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(btn_save)
                        .addGap(18, 18, 18)
                        .addComponent(btn_reset))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtcategory_name, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtprice, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(txtstatus_name, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(txtsupplier_name, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtsupplier_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtprice, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtstatus_name, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 69, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtname, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtstock, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtcategory_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btn_reset)
                            .addComponent(btn_save))))
                .addContainerGap())
        );

        jScrollPane1.setBackground(new java.awt.Color(255, 255, 255));
        jScrollPane1.setPreferredSize(new java.awt.Dimension(450, 200));

        tb_product.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tb_product.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tb_productMouseClicked(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                tb_productMouseReleased(evt);
            }
        });
        tb_product.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tb_productKeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(tb_product);

        btn_searchproduct.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/search.png"))); // NOI18N
        btn_searchproduct.setMaximumSize(new java.awt.Dimension(22, 22));
        btn_searchproduct.setMinimumSize(new java.awt.Dimension(22, 22));
        btn_searchproduct.setPreferredSize(new java.awt.Dimension(22, 22));
        btn_searchproduct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_searchproductActionPerformed(evt);
            }
        });

        btn_clearsearch.setBackground(new java.awt.Color(0, 204, 0));
        btn_clearsearch.setText("Clear");
        btn_clearsearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_clearsearchActionPerformed(evt);
            }
        });

        btn_print.setBackground(new java.awt.Color(0, 204, 0));
        btn_print.setText("Print");
        btn_print.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_printActionPerformed(evt);
            }
        });

        lb_count_rows.setText("Datacount");
        lb_count_rows.setMaximumSize(new java.awt.Dimension(100, 16));
        lb_count_rows.setMinimumSize(new java.awt.Dimension(100, 16));
        lb_count_rows.setPreferredSize(new java.awt.Dimension(100, 16));

        btn_cancel.setText("Cancel");
        btn_cancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cancelActionPerformed(evt);
            }
        });

        btn_delete.setBackground(new java.awt.Color(255, 0, 0));
        btn_delete.setForeground(new java.awt.Color(255, 255, 255));
        btn_delete.setText("Delete");
        btn_delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_deleteActionPerformed(evt);
            }
        });

        txtid.setMinimumSize(new java.awt.Dimension(170, 22));
        txtid.setPreferredSize(new java.awt.Dimension(170, 22));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(jLabel1)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(lb_count_rows, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txtid, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtcategory_id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtsupplier_id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtstatus_id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(btn_cancel)
                                .addGap(18, 18, 18)
                                .addComponent(btn_delete)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 59, Short.MAX_VALUE)
                                .addComponent(txt_searchproduct, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(btn_searchproduct, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(btn_clearsearch)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(btn_print))
                            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btn_clearsearch)
                        .addComponent(btn_print))
                    .addComponent(btn_searchproduct, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txt_searchproduct, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btn_delete)
                        .addComponent(btn_cancel)))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lb_count_rows, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtstatus_id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtsupplier_id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtcategory_id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtid, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.getAccessibleContext().setAccessibleName("");

        add(jPanel1, "card2");
    }// </editor-fold>//GEN-END:initComponents

    private void btn_saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_saveActionPerformed
        String row_id = txtid.getText();
        String row_name = txtname.getText();
        String row_category = txtcategory_id.getText();
        String row_stock = txtstock.getText();
        String row_supplier = txtsupplier_id.getText();
        String row_price = txtprice.getText();
        String row_status = txtstatus_id.getText();
        //String row_txtkode = txt_kode.getText();
        //String row_txtsupplier = txttemp_IDsupplier.getText();
        //int c_kode = 0;
        
        if (!"".equals(row_name) && !"".equals(row_category) && !"".equals(row_stock) && !"".equals(row_supplier) && !"".equals(row_price) && !"".equals(row_status)) {
           ProductObjectCreation();
            if ("".equals(row_id)) {
                pdb.insertProduct(products);
                //generate(row_txtkode);
            } else {
                pdb.updateProduct(products);
                //btn_dapatKode.setVisible(true);
            }
                btn_reset.doClick();
                GetData();
        } else {
            JOptionPane.showMessageDialog(null, "All input field are required!.");
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_saveActionPerformed

    private void btn_printActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_printActionPerformed
        try {
            String report = ("/report/produk.jrxml");
            HashMap hash = new HashMap();

            hash.put("",0);
            //JasperReport JRpt = JasperCompileManager.compileReport(report);
            //JasperPrint JPrint = JasperFillManager.fillReport(JRpt, hash, Koneksi.getConnection());
            // JasperViewer.viewReport(JPrint, false);
            } catch (Exception e) {
                System.out.println("Tidak dapat menampilkan struk karena " + e);
            }
 // TODO add your handling code here:
    }//GEN-LAST:event_btn_printActionPerformed

    private void btn_searchproductActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_searchproductActionPerformed
        searchProduct();
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_searchproductActionPerformed

    private void btn_clearsearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_clearsearchActionPerformed
        GetData();
        //barcode.setIcon(null);
        //btn_dapatKode.setVisible(true);
        txtid.setText("");
        txt_searchproduct.setText("");
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_clearsearchActionPerformed

    private void btn_resetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_resetActionPerformed
        btn_cancel.doClick();
        //btn_dapatKode.setVisible(true);
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_resetActionPerformed

    private void btn_deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_deleteActionPerformed
        int ok = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete this product?", "Confirmation", JOptionPane.OK_CANCEL_OPTION);
        if (ok == 0) {
            int productId = Integer.parseInt(txtid.getText());
            pdb.deleteProduct(productId);
            btn_cancel.doClick();
            GetData();
        }
// TODO add your handling code here:
    }//GEN-LAST:event_btn_deleteActionPerformed

    private void btn_cancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cancelActionPerformed
        tb_product.clearSelection();
        TxtEmpty();
        BtnEnabled(false);
        //barcode.setIcon(null);
        btn_save.setText("Save");
        txtname.requestFocus();
        //btn_dapatKode.setVisible(true);
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_cancelActionPerformed

    private void tb_productKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tb_productKeyReleased
        GetData_View();
        // TODO add your handling code here:
    }//GEN-LAST:event_tb_productKeyReleased

    private void tb_productMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tb_productMouseClicked
        GetData_View();
        TbClick();
        // TODO add your handling code here:
    }//GEN-LAST:event_tb_productMouseClicked

    private void tb_productMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tb_productMouseReleased
        GetData_View();
        TbClick();
        // TODO add your handling code here:
    }//GEN-LAST:event_tb_productMouseReleased

    private void txtstatus_nameItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_txtstatus_nameItemStateChanged
        String status_name = txtstatus_name.getSelectedItem().toString();
        if("".equals(status_name)){
            txtstatus_id.setText("");
        }else if("Pending".equals(status_name)){
            txtstatus_id.setText("0");
        }else{
            txtstatus_id.setText("1");
        }
// TODO add your handling code here:
    }//GEN-LAST:event_txtstatus_nameItemStateChanged

    private void txtpriceKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtpriceKeyTyped
        char c = evt.getKeyChar();
        if(!(Character.isDigit(c) || c== KeyEvent.VK_BACK_SPACE || c == KeyEvent.VK_DELETE ))
        {
            JOptionPane.showMessageDialog(null, "Input must be a number", "Illegal Input", JOptionPane.ERROR_MESSAGE);
            evt.consume();
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_txtpriceKeyTyped

    private void txtstockKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtstockKeyTyped
        char c = evt.getKeyChar();
        if(!(Character.isDigit(c) || c== KeyEvent.VK_BACK_SPACE || c == KeyEvent.VK_DELETE ))
        {
            JOptionPane.showMessageDialog(null, "Input must be a number", "Illegal Input", JOptionPane.ERROR_MESSAGE);
            evt.consume();
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_txtstockKeyTyped

    private void txtsupplier_nameItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_txtsupplier_nameItemStateChanged
        String supplier_name = txtsupplier_name.getSelectedItem().toString();
        if (!supplier_name.equals("")) {
            try {
                ResultSet result = sdb.selectedSupplierByName(supplier_name);
                if (result.next()) {
                    txtsupplier_id.setText(result.getString("id"));
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error " + e);
            } finally {
                sdb.flushAll();
            }
        } else {
            txtsupplier_id.setText("");
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_txtsupplier_nameItemStateChanged

    private void txtcategory_nameItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_txtcategory_nameItemStateChanged
        String category_name = txtcategory_name.getSelectedItem().toString();
        if (!category_name.equals("")) {
            ResultSet result = cdb.selectedCategoryByName(category_name);
            try {
                if (result.next()) {
                    txtcategory_id.setText(result.getString("id"));
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error " + e);
            } finally {
                cdb.flushAll();
            }
        } else {
            txtcategory_id.setText("");
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_txtcategory_nameItemStateChanged


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_cancel;
    private javax.swing.JButton btn_clearsearch;
    private javax.swing.JButton btn_delete;
    private javax.swing.JButton btn_print;
    private javax.swing.JButton btn_reset;
    private javax.swing.JButton btn_save;
    private javax.swing.JButton btn_searchproduct;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lb_count_rows;
    private javax.swing.JTable tb_product;
    private javax.swing.JTextField txt_searchproduct;
    private javax.swing.JTextField txtcategory_id;
    private javax.swing.JComboBox<String> txtcategory_name;
    private javax.swing.JTextField txtid;
    private javax.swing.JTextField txtname;
    private javax.swing.JTextField txtprice;
    private javax.swing.JTextField txtstatus_id;
    private javax.swing.JComboBox<String> txtstatus_name;
    private javax.swing.JTextField txtstock;
    private javax.swing.JTextField txtsupplier_id;
    private javax.swing.JComboBox<String> txtsupplier_name;
    // End of variables declaration//GEN-END:variables
}
