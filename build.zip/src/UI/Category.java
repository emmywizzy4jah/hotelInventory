/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package UI;

import Classes.Categories;
import DatabaseOperation.CategoryDb;
import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author user
 */
public class Category extends javax.swing.JPanel {

    Categories categories;
    CategoryDb cdb = new CategoryDb();
    ResultSet result;
    /**
     * Creates new form Category
     */
    public Category() {
        initComponents();
        GetData();
        BtnEnabled(false);
        btn_save.setText("Save");
        //txtid.setEditable(false);
        txtid.hide();
        txtstatus_id.hide();
    }

    private void TxtEmpty() {
        txtid.setText("");
        txtname.setText("");
        txtstatus_id.setText("");
        txtstatus_name.setSelectedItem("Select");
    }

    private void BtnEnabled(boolean x) {
        btn_delete.setEnabled(x);
    }
    
    private void SearchObjectCreation()
    {
        categories = new Categories();
        categories.setSearchQuery(txt_searchcategory.getText());
    }
    
    private void CategoryObjectCreation()
    {
        categories = new Categories();
        try{
            categories.setId(Integer.parseInt(txtid.getText()));
        } catch(Exception ex) {
            categories.setId(0);
        }
        categories.setName(txtname.getText());
        categories.setStatus(txtstatus_id.getText());
        
        //products.setSearchQuery(txt_searchproduct.getText());
    }
    
    private void GetData() {
        try {
            result = cdb.GetData();
           
            DefaultTableModel category = new DefaultTableModel();
            category.addColumn("ID");
            category.addColumn("Name");

            //category.getDataVector().removeAllElements();
            //category.fireTableDataChanged();
           // category.setRowCount(0);

            while (result.next()) {
                category.addRow(new Object[]{
                    result.getString("id"),
                    result.getString("category_name")
                });
                tb_category.setModel(category);
            }
            
            //sql.last();
            String count_rows = String.valueOf(tb_category.getRowCount());
            lb_count_rows.setText("Row Data : " + count_rows);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error " + e);
        }finally{
            cdb.flushAll();
        }
    }

    private void GetData_View() {
        
        categories = new Categories();
        
        int row = tb_category.getSelectedRow();
        String row_id = (tb_category.getModel().getValueAt(row, 0).toString());
        txtid.setText(row_id);
        BtnEnabled(true);
    }

    private void TbClick() {
        String row_id = txtid.getText();
        int categoryId = Integer.parseInt(txtid.getText());
        if (!"0".equals(row_id)) {
            try {
                btn_save.setText("Edit");
                result = cdb.selectedCategoryById(categoryId);
                if (result.next()) {
                    //System.out.println(">>>>>>>>>> "+ result.getString("status"));
                    txtid.setText(row_id);
                    //txtid.setText(Integer.toString(result.getInt("id")));
                    txtname.setText(result.getString("category_name"));
                    txtstatus_id.setText(result.getString("category_status"));
                    
                    if("0".equals(result.getString("category_status"))){
                        txtstatus_name.setSelectedItem("Pending");
                    }else{
                        txtstatus_name.setSelectedItem("Published");
                    }
                            
                    //txttemp_kode.setText(kode);
                    //ImageIcon imgThisImg = new ImageIcon("src" + "/" + "img" + "/barcode/" + txt_kode.getText() + ".png");
                    //barcode.setIcon(imgThisImg);
                    txtname.requestFocus();
                }
                //txt_kode.setEditable(false);
                //btn_dapatKode.hide();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Error " + e);
            } finally {
            cdb.flushAll();
        }
        } else {
            JOptionPane.showMessageDialog(null, "Terdapat kesalahan id null!");
        }
    }
    
    private void searchCategory() {
        SearchObjectCreation();
        try {
            result = cdb.searchCategory(categories);
            
            DefaultTableModel category = new DefaultTableModel();
            category.addColumn("ID");
            category.addColumn("Name");

            //category.getDataVector().removeAllElements();
            //category.fireTableDataChanged();
           // category.setRowCount(0);

            while (result.next()) {
                category.addRow(new Object[]{
                    result.getString("id"),
                    result.getString("category_name")
                });
                tb_category.setModel(category);
            }

            //sql.last();
            String count_rows = String.valueOf(tb_category.getRowCount());
            lb_count_rows.setText("Row Data : " + count_rows);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error " + e);
        }finally{
            cdb.flushAll();
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txtname = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtstatus_name = new javax.swing.JComboBox<>();
        btn_save = new javax.swing.JButton();
        btn_reset = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tb_category = new javax.swing.JTable();
        txtid = new javax.swing.JTextField();
        btn_delete = new javax.swing.JButton();
        btn_cancel = new javax.swing.JButton();
        lb_count_rows = new javax.swing.JLabel();
        txtstatus_id = new javax.swing.JTextField();
        txt_searchcategory = new javax.swing.JTextField();
        btn_searchcategory = new javax.swing.JButton();
        btn_clearsearch = new javax.swing.JButton();

        setPreferredSize(new java.awt.Dimension(636, 573));
        setLayout(new java.awt.CardLayout());

        jPanel1.setBackground(new java.awt.Color(210, 218, 255));

        jLabel1.setFont(new java.awt.Font("SansSerif", 1, 24)); // NOI18N
        jLabel1.setText("Category");
        jLabel1.setMaximumSize(new java.awt.Dimension(104, 32));
        jLabel1.setMinimumSize(new java.awt.Dimension(104, 32));
        jLabel1.setPreferredSize(new java.awt.Dimension(104, 32));

        jPanel2.setMinimumSize(new java.awt.Dimension(0, 0));
        jPanel2.setPreferredSize(new java.awt.Dimension(624, 137));

        jLabel2.setText("Category Name :");
        jLabel2.setMaximumSize(new java.awt.Dimension(100, 16));
        jLabel2.setMinimumSize(new java.awt.Dimension(100, 16));
        jLabel2.setPreferredSize(new java.awt.Dimension(100, 16));

        txtname.setMinimumSize(new java.awt.Dimension(170, 22));
        txtname.setPreferredSize(new java.awt.Dimension(170, 22));

        jLabel3.setText("Select Status  :");
        jLabel3.setMaximumSize(new java.awt.Dimension(100, 16));
        jLabel3.setMinimumSize(new java.awt.Dimension(100, 16));
        jLabel3.setPreferredSize(new java.awt.Dimension(100, 16));

        txtstatus_name.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select", "Pending", "Published" }));
        txtstatus_name.setMinimumSize(new java.awt.Dimension(170, 22));
        txtstatus_name.setPreferredSize(new java.awt.Dimension(170, 22));
        txtstatus_name.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                txtstatus_nameItemStateChanged(evt);
            }
        });

        btn_save.setBackground(new java.awt.Color(0, 204, 0));
        btn_save.setText("Save");
        btn_save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_saveActionPerformed(evt);
            }
        });

        btn_reset.setText("Reset");
        btn_reset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_resetActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(txtname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(txtstatus_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(btn_save)
                        .addGap(18, 18, 18)
                        .addComponent(btn_reset)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtstatus_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 46, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_reset)
                    .addComponent(btn_save))
                .addContainerGap())
        );

        jScrollPane1.setBackground(new java.awt.Color(255, 255, 255));
        jScrollPane1.setPreferredSize(new java.awt.Dimension(450, 200));

        tb_category.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tb_category.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tb_categoryMouseClicked(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                tb_categoryMouseReleased(evt);
            }
        });
        tb_category.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tb_categoryKeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(tb_category);

        btn_delete.setBackground(new java.awt.Color(255, 0, 0));
        btn_delete.setForeground(new java.awt.Color(255, 255, 255));
        btn_delete.setText("Delete");
        btn_delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_deleteActionPerformed(evt);
            }
        });

        btn_cancel.setText("Cancel");
        btn_cancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cancelActionPerformed(evt);
            }
        });

        lb_count_rows.setText("Datacount");
        lb_count_rows.setMaximumSize(new java.awt.Dimension(100, 16));
        lb_count_rows.setMinimumSize(new java.awt.Dimension(100, 16));
        lb_count_rows.setPreferredSize(new java.awt.Dimension(100, 16));

        btn_searchcategory.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/search.png"))); // NOI18N
        btn_searchcategory.setMaximumSize(new java.awt.Dimension(22, 22));
        btn_searchcategory.setMinimumSize(new java.awt.Dimension(22, 22));
        btn_searchcategory.setPreferredSize(new java.awt.Dimension(22, 22));
        btn_searchcategory.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_searchcategoryActionPerformed(evt);
            }
        });

        btn_clearsearch.setBackground(new java.awt.Color(0, 204, 0));
        btn_clearsearch.setText("Clear");
        btn_clearsearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_clearsearchActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addComponent(btn_cancel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btn_delete)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(txt_searchcategory, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btn_searchcategory, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_clearsearch)
                .addContainerGap())
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 624, Short.MAX_VALUE))))
                .addContainerGap())
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(lb_count_rows, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(txtid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(43, 43, 43)
                .addComponent(txtstatus_id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(43, 43, 43))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(btn_delete)
                                .addComponent(btn_cancel))
                            .addComponent(btn_clearsearch)))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(txt_searchcategory, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btn_searchcategory, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lb_count_rows, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtstatus_id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        add(jPanel1, "card2");
    }// </editor-fold>//GEN-END:initComponents

    private void txtstatus_nameItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_txtstatus_nameItemStateChanged
        String status_name = txtstatus_name.getSelectedItem().toString();
        if("".equals(status_name)){
            txtstatus_id.setText("");
        }else if("Pending".equals(status_name)){
            txtstatus_id.setText("0");
        }else{
            txtstatus_id.setText("1");
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_txtstatus_nameItemStateChanged

    private void tb_categoryKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tb_categoryKeyReleased
        GetData_View();
        // TODO add your handling code here:
    }//GEN-LAST:event_tb_categoryKeyReleased

    private void tb_categoryMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tb_categoryMouseClicked
        GetData_View();
        TbClick();
        // TODO add your handling code here:
    }//GEN-LAST:event_tb_categoryMouseClicked

    private void tb_categoryMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tb_categoryMouseReleased
        GetData_View();
        TbClick();
        // TODO add your handling code here:
    }//GEN-LAST:event_tb_categoryMouseReleased

    private void btn_searchcategoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_searchcategoryActionPerformed
        searchCategory();
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_searchcategoryActionPerformed

    private void btn_cancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cancelActionPerformed
        tb_category.clearSelection();
        TxtEmpty();
        BtnEnabled(false);
        //barcode.setIcon(null);
        btn_save.setText("Save");
        txtname.requestFocus();
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_cancelActionPerformed

    private void btn_deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_deleteActionPerformed
      int ok = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete this category?", "Confirmation", JOptionPane.OK_CANCEL_OPTION);
        if (ok == 0) {
            int categoryId = Integer.parseInt(txtid.getText());
            cdb.deleteCategory(categoryId);
            btn_cancel.doClick();
            GetData();
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_deleteActionPerformed

    private void btn_resetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_resetActionPerformed
        btn_cancel.doClick();
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_resetActionPerformed

    private void btn_saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_saveActionPerformed
        String row_id = txtid.getText();
        String row_name = txtname.getText();
        String row_status = txtstatus_id.getText();
        
        
        if (!"".equals(row_name) && !"".equals(row_status)) {
           
            CategoryObjectCreation();
            if ("".equals(row_id)) {
                cdb.insertCategory(categories);
                btn_reset.doClick();
                GetData();
                //generate(row_txtkode);
            } else {
                cdb.updateCategory(categories);
                btn_reset.doClick();
                GetData();
                //btn_dapatKode.setVisible(true);
            }
        } else {
            JOptionPane.showMessageDialog(null, "All input field are required!.");
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_saveActionPerformed

    private void btn_clearsearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_clearsearchActionPerformed
        GetData();
        txtid.setText("");
        txt_searchcategory.setText("");
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_clearsearchActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_cancel;
    private javax.swing.JButton btn_clearsearch;
    private javax.swing.JButton btn_delete;
    private javax.swing.JButton btn_reset;
    private javax.swing.JButton btn_save;
    private javax.swing.JButton btn_searchcategory;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lb_count_rows;
    private javax.swing.JTable tb_category;
    private javax.swing.JTextField txt_searchcategory;
    private javax.swing.JTextField txtid;
    private javax.swing.JTextField txtname;
    private javax.swing.JTextField txtstatus_id;
    private javax.swing.JComboBox<String> txtstatus_name;
    // End of variables declaration//GEN-END:variables
}
