/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DatabaseOperation;

import Classes.Purchases;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.JOptionPane;

/**
 *
 * @author user
 */
public class PurchaseDb {
    Connection conn = null;
    PreparedStatement statement = null;
    ResultSet result = null;
    
    public void insertSell(Purchases purchases) {
        LocalDateTime myDateObj = LocalDateTime.now();
        DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String created_at = myDateObj.format(myFormatObj);
        try {
            conn = DatabaseConnection.connectTODB(); //'discount','staff_name',
            String insertTrans = "INSERT INTO purchases('date','total','grandtotal','created_at') "
                + "VALUES ('" + purchases.getDate() + "',"
                    + "'" + purchases.getTotal() + "',"
                    //+ "'" + purchases.getDiscount() + "',"  
                    + "'" + purchases.getGrandTotal() + "',"
                    //+ "'" + purchases.getStaff() + "',"
                    + "'" + created_at + "')";
            statement = conn.prepareStatement(insertTrans);
            statement.executeUpdate();
            
            String last_id  = "SELECT last_insert_rowid()";
            statement = conn.prepareStatement(last_id);
           result = statement.executeQuery();
            if (!result.next()) {
                System.out.println("Something is wrong...");
                return;
            }
            final Integer purchase_id = result.getInt("last_insert_rowid()");
            //System.out.println("The last inserted id is " + sell_id);
            
            for (int i = 0; i < purchases.getTbRowCount(); i++) {
                String detail = "INSERT INTO purchase_details('purchase_id','product_id','purchase_quantity','purchase_subtotal','created_at') "
                    + "VALUES ('" + purchase_id + "',"
                    //+ "'" + Integer.valueOf(purchases.getTb().getText()) + "','"
                    + "'" + purchases.getTb().getValueAt(i, 0) + "',"
                    + "'" + purchases.getTb().getValueAt(i, 3) + "',"
                    + "'" + purchases.getTb().getValueAt(i, 5) + "',"
                    + "'" + created_at + "')";
                statement = conn.prepareStatement(detail);
                statement.executeUpdate();
                
                int quantity = Integer.parseInt(purchases.getTb().getValueAt(i, 3).toString());
                int stock = Integer.parseInt(purchases.getTb().getValueAt(i, 2).toString());
                
                String updateQuery = "UPDATE products SET "
                    + "stock= '" + Integer.valueOf(stock + quantity).toString()
                    + "' WHERE id = " + purchases.getTb().getValueAt(i, 0);
                 
            statement = conn.prepareStatement(updateQuery);
            int x = statement.executeUpdate();
            }
            JOptionPane.showMessageDialog(null, "New Purchases successfully inserted");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n" + "InsertQuery Failed");
        } finally{
            flushAll();
        }         
    }
    
    public void flushStatementOnly()
    {
        if (statement != null) {
            try {
                statement.close();
            } catch (SQLException ex) {
                System.err.print(ex.toString());
            }
        }
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException ex) {
                System.err.print(ex.toString());
            }
        }
    }
    
    public void flushAll()
    {
        if (result != null) {
            try {
                result.close();
            } catch (SQLException ex) {
                System.err.print(ex.toString());
            }
        }
        if (statement != null) {
            try {
                statement.close();
            } catch (SQLException ex) {
                System.err.print(ex.toString());
            }
        }
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException ex) {
                System.err.print(ex.toString());
            }
        }
    } 
}