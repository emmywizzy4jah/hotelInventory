/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DatabaseOperation;

import java.sql.*;

/**
 *
 * @author user
 */
public class CreateTable {


    public static void main( String args[] )
    {
Connection c = null;
PreparedStatement stmt = null;
ResultSet rs = null;
        try {
//Class.forName("org.sqlite.JDBC");
c = DriverManager.getConnection("jdbc:sqlite:hotelinventory.sqlite");
System.out.println("Database Opened...\n");
   //"DROP TABLE admins"; 
            //String sql = "CREATE TABLE admins ("
            //    + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
            //    + "name varchar NOT NULL,"
            //    + "username varchar NOT NULL,"
            //    + "password varchar NOT NULL,"
            //    + "address varchar NOT NULL,"
            //    + "phone varchar NOT NULL,"
            //    + "role varchar DEFAULT admin,"
            //   + "active_status varchar DEFAULT 0,"
            //    + "created_at timestamp NOT NULL)";

            //String sql = "CREATE TABLE categories ("
             //   + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
            //    + "category_name varchar NOT NULL,"
            //    + "category_status varchar DEFAULT 0,"
            //    + "created_at timestamp NOT NULL)";
            
            //String sql = "CREATE TABLE suppliers ("
            //    + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
            //    + "supplier_name varchar NOT NULL,"
            //    + "supplier_status varchar DEFAULT 0,"
            //    + "created_at timestamp NOT NULL)";
            
            //String sql = "CREATE TABLE products ("
              //  + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
              //  + "product_name varchar NOT NULL,"
              // // + "description varchar NOT NULL,"
              //  + "category_id varchar NOT NULL,"
              //  + "supplier_id varchar NOT NULL,"
               // + "price varchar NOT NULL,"
               // + "stock varchar DEFAULT 0,"
               // + "product_status varchar DEFAULT 0,"
                //+ "created_at timestamp NOT NULL)";
                
            //String sql = "CREATE TABLE sells ("
            //    + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
            //    + "date date NOT NULL,"
            //    + "total varchar NOT NULL,"
            //    + "discount varchar NOT NULL,"
            //    + "grandtotal varchar NOT NULL,"
            //    + "staff_name varchar NOT NULL,"
            //    + "sells_status varchar DEFAULT 1,"
            //    + "created_at timestamp NOT NULL)";
            
            //String sql = "CREATE TABLE sell_details ("
            //    + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
            //    + "sell_id varchar NOT NULL,"
            //    + "product_id varchar NOT NULL,"
            //    + "sell_quantity varchar NOT NULL,"
            //    + "sell_subtotal varchar NOT NULL,"
            //    + "sell_detail_status varchar DEFAULT 1,"
            //    + "created_at timestamp NOT NULL)";
            
                
            //String sql = "CREATE TABLE purchases ("
            //    + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
            //    + "date date NOT NULL,"
            //    + "total varchar NULL,"
            //    + "discount varchar NULL,"
            //    + "grandtotal varchar NULL,"
            //    + "staff_name varchar NULL,"
            //    + "purchases_status varchar DEFAULT 1,"
            //    + "created_at timestamp NOT NULL)";
            
            String sql = "CREATE TABLE purchase_details ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "purchase_id varchar NOT NULL,"
                + "product_id varchar NOT NULL,"
                + "purchase_quantity varchar NOT NULL,"
                + "purchase_subtotal varchar NOT NULL,"
                + "purchase_detail_status varchar DEFAULT 1,"
                + "created_at timestamp NOT NULL)";
            
  //String sql = "UPDATE admins SET role = 'admin' WHERE id = 1";
   //String sql = "DROP TABLE sell_details";
  //String sql = "ALTER TABLE suppliers ADD COLUMN supplier_phone";
      
//String sql = "INSERT INTO admins (name, username, password, Address, phone, role, active_status, created_at)"
//+ "VALUES ('Admin', 'admin', 'password', 'Paulosa', '4006', 'admin', '1', '2024-06-01 13:17:20')";

//String sql = "INSERT INTO categories (category_name, category_status, created_at)"
//+ "VALUES ('Drink', '1', '2024-06-01 13:17:20')";
  
//String sql = "INSERT INTO suppliers (supplier_name, supplier_phone, supplier_status, created_at)"
//+ "VALUES ('Joe', '081235675', '1', '2024-06-01 13:17:20')";
  
//String sql = "INSERT INTO products (product_name, category_id, supplier_id, price, stock, product_status, created_at)"
//+ "VALUES ('Rice', '1', '1', '800', '10', '1', '2024-06-01 13:17:20')";
    stmt = c.prepareStatement(sql);
            stmt.execute();
}catch (SQLException e) {
    System.err.println( e.getClass().getName() + ": " + e.getMessage() );
    System.exit(0);
}finally {
    try {    
        //rs.close();
        stmt.close();
        c.close();
    }catch(SQLException ex){
        System.err.print(ex.toString()+" >> ERROR CLOSING DB");
}
        }
System.out.println("Table Admin Created Successfully!!!");
    }
}