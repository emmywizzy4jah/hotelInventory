/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DatabaseOperation;

import Classes.Categories;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.JOptionPane;

/**
 *
 * @author user
 */
public class CategoryDb {
    Connection conn = null;
    PreparedStatement statement = null;
    ResultSet result = null;
    
     public void insertCategory(Categories categories) { 
        LocalDateTime myDateObj = LocalDateTime.now();
        DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String created_at = myDateObj.format(myFormatObj);
        try {
         conn = DatabaseConnection.connectTODB();
            //stmt = conn.createStatement();
            String insertQuery = "insert into categories('category_name','category_status','created_at') "
                    + "values('" + categories.getName() + "',"
                    + "'" + categories.getStatus() + "',"
                    + "'" + created_at + "')";

            statement = conn.prepareStatement(insertQuery);
             //System.out.println(">>>>>>>>>> "+ statement.executeQuery());
            int x = statement.executeUpdate();
            if (x > 0){
                JOptionPane.showMessageDialog(null, "New category successfully inserted");
            }else{
                JOptionPane.showMessageDialog(null, "New category not successfully inserted");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n" + "InsertQuery of insertItem Failed");
        } finally {
            flushStatementOnly();
        }
    }

    public void updateCategory(Categories categories) {
        try {
         conn = DatabaseConnection.connectTODB();
            String updateQuery = "UPDATE categories SET category_name= '" + categories.getName() 
                    + "', category_status = '" + categories.getStatus()
                    + "' WHERE id = " + categories.getId();

            // System.out.println(">>>>>>>>>> "+ insertRoomTypeQuery);
            statement = conn.prepareStatement(updateQuery);
            int x = statement.executeUpdate();
            if (x > 0){
                JOptionPane.showMessageDialog(null, "Category successfully updated");
            }else{
                JOptionPane.showMessageDialog(null, "Category not successfully updated");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n" + "Update Product failed");
        } finally {
            flushStatementOnly();
        }
    }
    
    public ResultSet getCategories() {
        try {
            conn = DatabaseConnection.connectTODB();
            String query = "select * from categories where category_status=1";
            statement = conn.prepareStatement(query);
            result = statement.executeQuery();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n error coming from returning all item DB Operation");
        }
        return result;
    }
    
    public ResultSet GetData(){
        try {
            conn = DatabaseConnection.connectTODB();
            String sql = "SELECT * FROM categories";
            statement = conn.prepareStatement(sql);
            result = statement.executeQuery();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n" + "Error returning count!");
        }
        return result;
    }
    
    public ResultSet selectedCategoryById(int CategoryId){
        try {
            conn = DatabaseConnection.connectTODB();
            String query = "SELECT * FROM categories WHERE id='" + CategoryId + "'";
            statement = conn.prepareStatement(query);
            result = statement.executeQuery();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n error coming from returning all item DB Operation");
        }
        return result;
    }
    
    public ResultSet selectedCategoryByName(String CategoryName){
        try {
            conn = DatabaseConnection.connectTODB();
            String query = "SELECT * FROM categories WHERE category_name='" + CategoryName + "'";
            statement = conn.prepareStatement(query);
            result = statement.executeQuery();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n error coming from returning all item DB Operation");
        }
        return result;
    }
    
    public ResultSet searchCategory(Categories categories){
        try {
         conn = DatabaseConnection.connectTODB();
            //System.out.println(">>>>>>>>>> "+ products.getSearchQuery());
            String sql = "SELECT * FROM categories WHERE category_name LIKE"
                    + " '%" + categories.getSearchQuery() + "%'";
            
            statement = conn.prepareStatement(sql);
            result = statement.executeQuery();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n error coming from returning all item DB Operation");
        }
        return result;
    }

    public void deleteCategory(int categoryId) {
        try {
         conn = DatabaseConnection.connectTODB();
            String deleteQuery = "delete from categories where id=" + categoryId;
            statement = conn.prepareStatement(deleteQuery);
            int x = statement.executeUpdate();
            if (x > 0){
                JOptionPane.showMessageDialog(null, "Category successfully deleted");
            }else{
                JOptionPane.showMessageDialog(null, "Category not successfully deleted");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n" + "Delete query Product Failed");
        } finally {
            flushStatementOnly();
        }
    }
    
    public void flushStatementOnly()
    {
        if (statement != null) {
            try {
                statement.close();
            } catch (SQLException ex) {
                System.err.print(ex.toString());
            }
        }
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException ex) {
                System.err.print(ex.toString());
            }
        }
    }
    
    public void flushAll()
    {
        if (result != null) {
            try {
                result.close();
            } catch (SQLException ex) {
                System.err.print(ex.toString());
            }
        }
        if (statement != null) {
            try {
                statement.close();
            } catch (SQLException ex) {
                System.err.print(ex.toString());
            }
        }
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException ex) {
                System.err.print(ex.toString());
            }
        }
    }  
}