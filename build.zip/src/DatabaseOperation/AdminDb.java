/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DatabaseOperation;

import Classes.Admins;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.JOptionPane;

/**
 *
 * @author user
 */
public class AdminDb {
    Connection conn = null;
    PreparedStatement statement = null;
    ResultSet result = null;
    
    public void insertAdmin(Admins admins)  
    {
        LocalDateTime myDate = LocalDateTime.now();
        DateTimeFormatter myFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String created_at = myDate.format(myFormat);
        try {
         conn = DatabaseConnection.connectTODB();
            String insertQuery = "INSERT INTO admins"
                    + "('name','username','password','address','phone','role','created_at')"
                    + " VALUES('" + admins.getName() + "',"
                    + "'" + admins.getUserName() + "',"
                    + "'" + admins.getPassword() + "',"
                    + "'" + admins.getAddress() + "',"
                    + "'" + admins.getPhone_no() + "',"
                    + "'" + admins.getRole() + "',"
                    + "'" + created_at + "')";

            //System.out.println(">>>>>>>>>> "+ insertQuery);
            statement = conn.prepareStatement(insertQuery);
            int x = statement.executeUpdate();
            if (x > 0){
                JOptionPane.showMessageDialog(null, "New Admin successfully inserted");
            }else{
                JOptionPane.showMessageDialog(null, "New Admin not successfully inserted");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n" + "InsertQuery Failed");
        } finally{
            flushStatementOnly();
        }         
    }
    
    public ResultSet loginAdmin(Admins admins)
    {      
        try {
         conn = DatabaseConnection.connectTODB();
            String loginQuery = "select * from admins where username='" + admins.getUserName() + "' AND password='" + admins.getPassword() +"'";
            
            //System.out.println(loginQuery);
            statement = conn.prepareStatement(loginQuery);
           result = statement.executeQuery();
                      
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n" + "Query Failed");
        }
        return result;
    }
    
    public void UpdateAdminPassword(Admins admins)
    {
        try {
         conn = DatabaseConnection.connectTODB();
            String passwordQuery = "UPDATE admins SET password='"+ admins.getPassword() + "' WHERE id="+ admins.getId();
            
            statement = conn.prepareStatement(passwordQuery);
            int x = statement.executeUpdate();
            if (x > 0){
                JOptionPane.showMessageDialog(null, "Password successfully updated");
            }else{
                JOptionPane.showMessageDialog(null, "Password not successfully updated");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n" + "Update Admin password query Failed");
        }finally{
            flushStatementOnly();
        }        
    }
    
    public void updateAdmin(Admins admins) 
    {
        // update admins set name = 'faysal' ,address = 'dhaka' where user_id = 3
        try{
         conn = DatabaseConnection.connectTODB();
            String updateQuery = "update admins set name = '"
                    + admins.getName() + "',"
                    + "address = '" + admins.getAddress() + "',"
                    + "phone = '" + admins.getPhone_no() + "',"
                    + "role = '" + admins.getRole() + "',"
                    + "active_status = '" + admins.getStatus() + "' where id= "
                    + admins.getId();

            //System.out.println(">>>>>>>>>> "+ insertQuery);
            //System.out.println(updateQuery);
            statement = conn.prepareStatement(updateQuery);
            int x = statement.executeUpdate();
            if (x > 0){
                JOptionPane.showMessageDialog(null, "Admin successfully updated");
            }else{
                JOptionPane.showMessageDialog(null, "Admin not successfully updated");
            }
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, ex.toString() + "\n" + "Update query Failed");
        }finally{
            flushStatementOnly();
        }
    }

    public void deleteAdmin(int adminId)
    {
        try {
            String deleteQuery = "delete from admins where id=" + adminId;
            statement = conn.prepareStatement(deleteQuery);
            statement.executeUpdate();
            JOptionPane.showMessageDialog(null, "Deleted Admin");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n" + "Delete query Failed");
        } finally {
            flushStatementOnly();
        }
    }

    public ResultSet getAllAdmin() 
    {
        try {
         conn = DatabaseConnection.connectTODB();
            String query = "select * from admins";
            statement = conn.prepareStatement(query);
            result = statement.executeQuery();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n error coming from returning all admin DB Operation");
        }
        return result;
    }
    
    public ResultSet searchAdmin(String queryTxt) 
    {
        try {
         conn = DatabaseConnection.connectTODB();
         String query = "SELECT * FROM admins WHERE name LIKE '%" + queryTxt + "%' OR phone LIKE '%" + queryTxt 
                    + "%' OR username LIKE '%" + queryTxt + "%' OR address LIKE '%" + queryTxt
                    + "%' OR role LIKE '%" + queryTxt + "%'";
         
            statement = conn.prepareStatement(query);
            result = statement.executeQuery();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n error coming from returning all admin DB Operation");
        }
        return result;
    }
    
    public ResultSet selectedAdminById(int adminId){
        try {
            conn = DatabaseConnection.connectTODB();
            String query = "SELECT * FROM admins WHERE id='" + adminId + "'";
            statement = conn.prepareStatement(query);
            result = statement.executeQuery();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n error coming from returning all item DB Operation");
        }
        return result;
    }
    
    public void flushStatementOnly()
    {
        if (statement != null) {
            try {
                statement.close();
            } catch (SQLException ex) {
                System.err.print(ex.toString());
            }
        }
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException ex) {
                System.err.print(ex.toString());
            }
        }
    }
    
    public void flushAll()
    {
        if (result != null) {
            try {
                result.close();
            } catch (SQLException ex) {
                System.err.print(ex.toString());
            }
        }
        if (statement != null) {
            try {
                statement.close();
            } catch (SQLException ex) {
                System.err.print(ex.toString());
            }
        }
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException ex) {
                System.err.print(ex.toString());
            }
        }
    }      
}