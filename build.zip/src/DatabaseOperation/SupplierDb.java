/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DatabaseOperation;

import Classes.Suppliers;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.JOptionPane;

/**
 *
 * @author user
 */
public class SupplierDb {
    Connection conn = null;
    PreparedStatement statement = null;
    ResultSet result = null;
    
     public void insertSupplier(Suppliers suppliers) { 
        LocalDateTime myDateObj = LocalDateTime.now();
        DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String created_at = myDateObj.format(myFormatObj);
        try {
         conn = DatabaseConnection.connectTODB();
            //stmt = conn.createStatement();
            String insertSupplier = "insert into suppliers('supplier_name','supplier_phone','supplier_status','created_at') "
                    + "values('" + suppliers.getName() + "',"
                    + "'" + suppliers.getPhone() + "',"
                    + "'" + suppliers.getStatus() + "',"
                    + "'" + created_at + "')";

            statement = conn.prepareStatement(insertSupplier);
             //System.out.println(">>>>>>>>>> "+ statement.executeQuery());
            int x = statement.executeUpdate();
            if (x > 0){
                JOptionPane.showMessageDialog(null, "New supplier successfully inserted");
            }else{
                JOptionPane.showMessageDialog(null, "New supplier not successfully inserted");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n" + "InsertQuery of insertItem Failed");
        } finally {
            flushStatementOnly();
        }
    }

    public void updateSupplier(Suppliers suppliers) {
        try {
         conn = DatabaseConnection.connectTODB();
            String updateSupplier = "UPDATE suppliers SET supplier_name= '" + suppliers.getName()
                    + "', supplier_phone = '" + suppliers.getPhone()
                    + "', supplier_status = '" + suppliers.getStatus()
                    + "' WHERE id = " + suppliers.getId();

            // System.out.println(">>>>>>>>>> "+ insertRoomTypeQuery);
            statement = conn.prepareStatement(updateSupplier);
            int x = statement.executeUpdate();
            if (x > 0){
                JOptionPane.showMessageDialog(null, "Supplier successfully updated");
            }else{
                JOptionPane.showMessageDialog(null, "Supplier not successfully updated");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n" + "Update Product failed");
        } finally {
            flushStatementOnly();
        }
    }

    public void deleteSupplier(int supplierId) {
        try {
         conn = DatabaseConnection.connectTODB();
            String deleteQuery = "delete from suppliers where id=" + supplierId;
            statement = conn.prepareStatement(deleteQuery);
            int x = statement.executeUpdate();
            if (x > 0){
                JOptionPane.showMessageDialog(null, "Supplier successfully deleted");
            }else{
                JOptionPane.showMessageDialog(null, "Supplier not successfully deleted");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n" + "Delete query Supplier Failed");
        } finally {
            flushStatementOnly();
        }
    }
    
    public ResultSet getSuppliers() {
        try {
         conn = DatabaseConnection.connectTODB();
            String query = "SELECT * FROM suppliers WHERE supplier_status='1'";
            statement = conn.prepareStatement(query);
            result = statement.executeQuery();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n error coming from returning all item DB Operation");
        }
        return result;
    }
    
    public ResultSet searchSupplier(Suppliers suppliers){
        try {
         conn = DatabaseConnection.connectTODB();
            //System.out.println(">>>>>>>>>> "+ products.getSearchQuery());
            String sql = "SELECT * FROM suppliers WHERE supplier_name LIKE"
                    + " '%" + suppliers.getSearchQuery() + "%'";
            
            statement = conn.prepareStatement(sql);
            result = statement.executeQuery();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n error coming from returning all item DB Operation");
        }
        return result;
    }
    
    public ResultSet GetData(){
        try {
         conn = DatabaseConnection.connectTODB();
            String sql = "SELECT * FROM suppliers";
            statement = conn.prepareStatement(sql);
            result = statement.executeQuery();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n" + "Error returning count!");
        }
        return result;
    }
    
    public ResultSet selectedSupplierById(int SupplierId){
        try {
            conn = DatabaseConnection.connectTODB();
            String query = "SELECT * FROM suppliers WHERE id='" + SupplierId + "'";
            statement = conn.prepareStatement(query);
            result = statement.executeQuery();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n error coming from returning all item DB Operation");
        }
        return result;
    }
    
    public ResultSet selectedSupplierByName(String SupplierName){
        try {
         conn = DatabaseConnection.connectTODB();
            String query = "SELECT * FROM suppliers WHERE supplier_name='" + SupplierName + "'";
            statement = conn.prepareStatement(query);
            result = statement.executeQuery();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n error coming from returning all item DB Operation");
        }
        return result;
    }
    
    public void flushStatementOnly()
    {
        if (statement != null) {
            try {
                statement.close();
            } catch (SQLException ex) {
                System.err.print(ex.toString());
            }
        }
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException ex) {
                System.err.print(ex.toString());
            }
        }
    }
    
    public void flushAll()
    {
        if (result != null) {
            try {
                result.close();
            } catch (SQLException ex) {
                System.err.print(ex.toString());
            }
        }
        if (statement != null) {
            try {
                statement.close();
            } catch (SQLException ex) {
                System.err.print(ex.toString());
            }
        }
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException ex) {
                System.err.print(ex.toString());
            }
        }
    }  
}