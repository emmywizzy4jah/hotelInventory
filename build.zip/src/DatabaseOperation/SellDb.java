/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DatabaseOperation;

import Classes.Sells;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.LocalDate;
import javax.swing.JOptionPane;

/**
 *
 * @author user
 */
public class SellDb {
    Connection conn = null;
    PreparedStatement statement = null;
    ResultSet result = null;
    
    public void insertSell(Sells sells) {
        LocalDateTime myDateObj = LocalDateTime.now();
        DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String created_at = myDateObj.format(myFormatObj);
        try {
            conn = DatabaseConnection.connectTODB();
            String insertTrans = "INSERT INTO sells('date','total','discount','grandtotal','staff_name','created_at') "
                + "VALUES ('" + sells.getDate() + "','" + sells.getTotal() + "','" + sells.getDiscount() + "',"  
                + "'" + sells.getGrandTotal() + "',"
                + "'" + sells.getStaff() + "',"
                    + "'" + created_at + "')";
            statement = conn.prepareStatement(insertTrans);
            statement.executeUpdate();
            
            String f  = "SELECT last_insert_rowid()";
            statement = conn.prepareStatement(f);
           result = statement.executeQuery();
            if (!result.next()) {
                System.out.println("Something is wrong...");
                return;
            }
            final Integer sell_id = result.getInt("last_insert_rowid()");
            //System.out.println("The last inserted id is " + sell_id);
            
            for (int i = 0; i < sells.getTbRowCount(); i++) {
                String detail = "INSERT INTO sell_details('sell_id','product_id','sell_quantity','sell_subtotal','created_at') "
                    + "VALUES ('" + sell_id + "','"
                    //+ Integer.valueOf(sells.getTb().getText()) + "','"
                    + "'" + sells.getTb().getValueAt(i, 0) + "',"
                    + "'" + sells.getTb().getValueAt(i, 3) + "',"
                    + "'" + sells.getTb().getValueAt(i, 5) + "',"
                    + "'" + created_at + "')";
                statement = conn.prepareStatement(detail);
                statement.executeUpdate();
                
                int quantity = Integer.parseInt(sells.getTb().getValueAt(i, 3).toString());
                int stock = Integer.parseInt(sells.getTb().getValueAt(i, 2).toString());
                
                String updateQuery = "UPDATE products SET "
                    + "stock= '" + Integer.valueOf(stock - quantity).toString()
                    + "' WHERE id = " + sells.getTb().getValueAt(i, 0);
                 
            statement = conn.prepareStatement(updateQuery);
            int x = statement.executeUpdate();
            }
            JOptionPane.showMessageDialog(null, "New Sales successfully inserted");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n" + "InsertQuery Failed");
        } finally{
            flushAll();
        }         
    }
    
    public ResultSet getallSalesamount(){
        try {
         conn = DatabaseConnection.connectTODB();
            //"SELECT * FROM suppliers WHERE supplier_name='1'";
            String query = "SELECT SUM(grandtotal) FROM sells";
            statement = conn.prepareStatement(query);
            result = statement.executeQuery();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n error coming from returning all item DB Operation");
        }
        return result;
    }
    
    
    public ResultSet gettodaySalesamount(){
             LocalDate current_date = LocalDate.now();
        try {
         conn = DatabaseConnection.connectTODB();
            //"SELECT * FROM suppliers WHERE supplier_name='1'";
            String query = "SELECT SUM(grandtotal) FROM sells WHERE date = '" + current_date + "'";
            statement = conn.prepareStatement(query);
            result = statement.executeQuery();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n error coming from returning all item DB Operation");
        }
        return result;
    }
    
    public ResultSet gettodaySales(){
        try {
             LocalDate myObj = LocalDate.now();
            // WHERE date = CURRENT_DATE;
            conn = DatabaseConnection.connectTODB();
            String query = "SELECT * FROM sells";
            statement = conn.prepareStatement(query);
            result = statement.executeQuery();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n error coming from returning all item DB Operation");
        }
        return result;
    }
    
    public ResultSet dailyItemSold(){
             LocalDate current_date = LocalDate.now();
        try {
            conn = DatabaseConnection.connectTODB();
            String query = "SELECT COUNT(id) FROM sells  WHERE date = '" + current_date + "'";
            statement = conn.prepareStatement(query);
            result = statement.executeQuery();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n error coming from returning all item DB Operation");
        }
        return result;
    }
    
    public void flushStatementOnly()
    {
        if (statement != null) {
            try {
                statement.close();
            } catch (SQLException ex) {
                System.err.print(ex.toString());
            }
        }
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException ex) {
                System.err.print(ex.toString());
            }
        }
    }
    
    public void flushAll()
    {
        if (result != null) {
            try {
                result.close();
            } catch (SQLException ex) {
                System.err.print(ex.toString());
            }
        }
        if (statement != null) {
            try {
                statement.close();
            } catch (SQLException ex) {
                System.err.print(ex.toString());
            }
        }
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException ex) {
                System.err.print(ex.toString());
            }
        }
    } 
}