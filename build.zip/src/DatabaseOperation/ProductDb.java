/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DatabaseOperation;

import Classes.Products;
import java.sql.*;
import javax.swing.JOptionPane;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author user
 */
public class ProductDb {
    Connection conn = null;
    PreparedStatement statement = null;
    Statement stmt = null;
    ResultSet result = null;
    
    //public ProductDb() {
      //  conn = DatabaseConnection.connectTODB();
    //}
    
     public void insertProduct(Products products) { 
        LocalDateTime myDateObj = LocalDateTime.now();
        DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String created_at = myDateObj.format(myFormatObj);
        try {
            conn = DatabaseConnection.connectTODB();
            String insertQuery = "insert into products('product_name','category_id','supplier_id','stock','price','product_status','created_at') "
                    + "values('" + products.getName() + "',"
                    + "'" + products.getCategory() + "',"
                    + "'" + products.getSupplier() + "',"
                    + "'" + products.getStock() + "',"
                    + "'" + products.getPrice() + "',"
                    + "'" + products.getStatus() + "',"
                    + "'" + created_at + "')";

            statement = conn.prepareStatement(insertQuery);
             //System.out.println(">>>>>>>>>> "+ statement.executeQuery());
            int x = statement.executeUpdate();
            if (x > 0){
                JOptionPane.showMessageDialog(null, "New product successfully inserted");
            }else{
                JOptionPane.showMessageDialog(null, "New product not successfully inserted");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n" + "InsertQuery of insertItem Failed");
        } finally {
            flushStatementOnly();
        }
    }

    public void updateProduct(Products products) {
        try {
            conn = DatabaseConnection.connectTODB();
            String updateQuery = "UPDATE products SET product_name= '" + products.getName() 
                    + "', category_id = '" + products.getCategory()
                    + "', supplier_id = '" + products.getSupplier()
                    + "', stock = '" + products.getStock() 
                    + "', price= '" + products.getPrice()  
                    + "', product_status = '" + products.getStatus()
                    + "' WHERE id = " + products.getId();

            // System.out.println(">>>>>>>>>> "+ insertRoomTypeQuery);
            statement = conn.prepareStatement(updateQuery);
            int x = statement.executeUpdate();
            if (x > 0){
                JOptionPane.showMessageDialog(null, "Product successfully updated");
            }else{
                JOptionPane.showMessageDialog(null, "Product not successfully updated");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n" + "Update Product failed");
        } finally {
            flushStatementOnly();
        }
    }

    public void deleteProduct(int ProductId) {
        try {
            conn = DatabaseConnection.connectTODB();
            String deleteQuery = "delete from products where id=" + ProductId;
            statement = conn.prepareStatement(deleteQuery);
            int x = statement.executeUpdate();
            if (x > 0){
                JOptionPane.showMessageDialog(null, "Product successfully deleted");
            }else{
                JOptionPane.showMessageDialog(null, "Product not successfully deleted");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n" + "Delete query Product Failed");
        } finally {
            flushStatementOnly();
        }
    }
    
    public ResultSet selectedProductById(int ProductId) {
        try {
            conn = DatabaseConnection.connectTODB();
            String sql = "SELECT products.id,products.product_name,products.stock,products.price,"
                    + "products.product_status,products.category_id,products.supplier_id,suppliers.supplier_name,"
                    + "categories.category_name"
                    + " FROM ((products"
                    + " INNER JOIN suppliers ON products.supplier_id = suppliers.id) "
                        + "INNER JOIN categories ON products.category_id = categories.id) "
                        //+ "INNER JOIN merek ON p.merek_Id = m.merek_Id "
                    + "WHERE products.id=' " + ProductId + "'";
        
            statement = conn.prepareStatement(sql);
            result = statement.executeQuery();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n" + "Error returning product!");
        }
        return result;
    }
    
    public ResultSet totalProduct() {
        try {
            conn = DatabaseConnection.connectTODB();
            String totalproductQuery = "SELECT COUNT(*) FROM products WHERE stock > 0";
            statement = conn.prepareStatement(totalproductQuery);
            //System.out.println(">>>>>>>>>> "+ statement);
            result = statement.executeQuery();
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n" + "Error returning count!");
        }
        return result;
    }
    
    public ResultSet GetData(){
        try {
            conn = DatabaseConnection.connectTODB();
            String sql = "SELECT products.id,products.product_name,products.stock,products.price,"
                    + "products.product_status,products.category_id,products.supplier_id,suppliers.supplier_name,"
                    + "categories.category_name"
                    + " FROM ((products"
                    + " INNER JOIN suppliers ON products.supplier_id = suppliers.id) "
                        + "INNER JOIN categories ON products.category_id = categories.id) "
                        //+ "INNER JOIN merek ON p.merek_Id = m.merek_Id "
                    //+ "WHERE products.product_status=1"
                    ;
            statement = conn.prepareStatement(sql);
            result = statement.executeQuery();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n" + "Error returning count!");
        }
        return result;
    }
    
    public ResultSet searchProduct(Products products){
        try {
            conn = DatabaseConnection.connectTODB();
            //System.out.println(">>>>>>>>>> "+ products.getSearchQuery());
            String sql = "SELECT products.id,products.product_name,products.stock,products.price,"
                    + "products.product_status,products.category_id,products.supplier_id,suppliers.supplier_name,"
                    + "categories.category_name"
                    + " FROM ((products"
                    + " INNER JOIN suppliers ON products.supplier_Id = suppliers.id) "
                        + "INNER JOIN categories ON products.category_id = categories.id) "
                        //+ "INNER JOIN merek ON p.merek_Id = m.merek_Id "
                    + "WHERE products.product_name LIKE '%" + products.getSearchQuery() 
                    + "%' OR price LIKE '%" + products.getSearchQuery() 
                    + "%' OR categories.category_name LIKE '%" + products.getSearchQuery()
                    //+ "%' OR brand_id LIKE '%" + products.getSearchQuery()
                    + "%' OR suppliers.supplier_name LIKE '%" + products.getSearchQuery() 
                    //+ "%' OR products.harga_jual LIKE '%" + products.getSearchQuery()
                   // + "%' OR stock LIKE '%" + products.getSearchQuery() 
                    + "%' OR products.stock LIKE '%" + products.getSearchQuery() + "%'";
            
            statement = conn.prepareStatement(sql);
            result = statement.executeQuery();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n error coming from returning all item DB Operation");
        }
        return result;
    }
    
    public ResultSet searchActiveProduct(Products products){
        try {
            conn = DatabaseConnection.connectTODB();
            //System.out.println(">>>>>>>>>> "+ products.getSearchQuery());
            String sql = "SELECT products.id,products.product_name,products.stock,products.price,"
                    + "products.product_status,products.category_id,products.supplier_id,suppliers.supplier_name,"
                    + "categories.category_name"
                    + " FROM ((products"
                    + " INNER JOIN suppliers ON products.category_id = suppliers.id) "
                        + "INNER JOIN categories ON products.category_id = categories.id) "
                        //+ "INNER JOIN merek ON p.merek_Id = m.merek_Id "
                    + "WHERE (products.product_name LIKE '%" + products.getSearchQuery() 
                    + "%' OR price LIKE '%" + products.getSearchQuery() 
                    + "%' OR categories.category_name LIKE '%" + products.getSearchQuery()
                    //+ "%' OR brand_id LIKE '%" + products.getSearchQuery()
                    + "%' OR suppliers.supplier_name LIKE '%" + products.getSearchQuery()  
                    + "%' OR products.stock LIKE '%" + products.getSearchQuery() + "%') AND products.product_status = 1";
            
            statement = conn.prepareStatement(sql);
            result = statement.executeQuery();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n error coming from returning all item DB Operation");
        }
        return result;
    }
    
    public ResultSet getProductStock(String stock) {
        try {
            conn = DatabaseConnection.connectTODB();
            String query = "select * from products limit " + stock;
            statement = conn.prepareStatement(query);
            result = statement.executeQuery();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n error coming from returning all item DB Operation");
        }
        return result;
    }
    
    public ResultSet getProduct() {
        try {
            conn = DatabaseConnection.connectTODB();
            String sql = "SELECT products.id,products.product_name,products.stock,products.price,"
                    + "products.product_status,products.category_id,products.supplier_id,suppliers.supplier_name,"
                    + "categories.category_name"
                    + " FROM ((products"
                    + " INNER JOIN suppliers ON products.supplier_id = suppliers.id) "
                        + "INNER JOIN categories ON products.category_id = categories.id) "
                        //+ "INNER JOIN merek ON p.merek_Id = m.merek_Id "
                    + "WHERE products.product_status=1";
            statement = conn.prepareStatement(sql);
            result = statement.executeQuery();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n error coming from returning all item DB Operation");
        }
        return result;
    }
    
    public void flushStatementOnly()
    {
        if (statement != null) {
            try {
                statement.close();
            } catch (SQLException ex) {
                System.err.print(ex.toString());
            }
        }
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException ex) {
                System.err.print(ex.toString());
            }
        }
    }
    
    public void flushAll()
    {
        if (result != null) {
            try {
                result.close();
            } catch (SQLException ex) {
                System.err.print(ex.toString());
            }
        }
        if (statement != null) {
            try {
                statement.close();
            } catch (SQLException ex) {
                System.err.print(ex.toString());
            }
        }
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException ex) {
                System.err.print(ex.toString());
            }
        }
    }
}
