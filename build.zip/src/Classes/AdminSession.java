/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

/**
 *
 * @author user
 */
public class AdminSession {
    private static int id;
    private static String name;
    private static String username;
    private static String password;
    private static String address;
    private static String phone_no;
    private static String role;
    private static String active_status;
    
    public static int getId() {
        return id;
    }

    public static void setId(int id) {
        AdminSession.id = id;
    }

    public static String getName() {
        return name;
    }

    public static void setName(String name) {
        AdminSession.name = name;
    }

    public static String getUserName() {
        return username;
    }

    public static void setUserName(String username) {
        AdminSession.username = username;
    }

    public static String getPassword() {
        return password;
    }

    public static void setPassword(String password) {
        AdminSession.password = password;
    }

    public static String getAddress() {
        return address;
    }

    public static void setAddress(String address) {
        AdminSession.address = address;
    }

    public static String getPhone_no() {
        return phone_no;
    }

    public static void setPhone_no(String phone_no) {
        AdminSession.phone_no = phone_no;
    }

    public static String getRole() {
        return role;
    }

    public static void setRole(String role) {
        AdminSession.role = role;
    }

    public String getStatus() {
        return active_status;
    }

    public void setStatus(String active_status) {
        AdminSession.active_status = active_status;
    } 
}