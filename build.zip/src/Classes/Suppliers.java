/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

/**
 *
 * @author user
 */
public class Suppliers {
    private int id;
    private String supplier_name;
    private String supplier_phone;
    private String supplier_status;
    private String search;
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return supplier_name;
    }

    public void setName(String supplier_name) {
        this.supplier_name = supplier_name;
    }

    public String getPhone() {
        return supplier_phone;
    }

    public void setPhone(String supplier_phone) {
        this.supplier_phone = supplier_phone;
    }

    public String getStatus() {
        return supplier_status;
    }

    public void setStatus(String supplier_status) {
        this.supplier_status = supplier_status;
    }

    public String getSearchQuery() {
        return search;
    }

    public void setSearchQuery(String search) {
        this.search = search;
    } 
}
