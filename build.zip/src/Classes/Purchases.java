/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

/**
 *
 * @author user
 */
public class Purchases {
    private int id;
    private String date;
    private int total;
    private int discount;
    private int grandtotal;
    private String staff;
    private int count;
    private javax.swing.JTable tb;
    private String product_status;
    private String search;
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    } 

    public String getDate() {
        return date;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public int getDiscount() {
        return discount;
    }

    public void setDiscount(int discount) {
        this.discount = discount;
    }

    public int getGrandTotal() {
        return grandtotal;
    }

    public void setGrandTotal(int grandtotal) {
        this.grandtotal = grandtotal;
    }

    public void setDate(String date) {
        this.date = date;
    }
    
    
    
    
    public int getTbRowCount() {
        return count;
    }

    public void setTbRowCount(int count) {
        this.count = count;
    }
    
    public javax.swing.JTable getTb() {
        return tb;
    }

    public void setTb(javax.swing.JTable tb) {
        this.tb = tb;
    }

    public String getStatus() {
        return product_status;
    }

    public void setStatus(String product_status) {
        this.product_status = product_status;
    }
    
    public String getSearchQuery() {
        return search;
    }

    public void setSearchQuery(String search) {
        this.search = search;
    }
}
