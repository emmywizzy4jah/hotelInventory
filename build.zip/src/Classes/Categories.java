/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

/**
 *
 * @author user
 */
public class Categories {
    private int id;
    private String category_name;
    private String category_status;
    private String search;
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return category_name;
    }

    public void setName(String category_name) {
        this.category_name = category_name;
    }

    public String getStatus() {
        return category_status;
    }

    public void setStatus(String category_status) {
        this.category_status = category_status;
    }

    public String getSearchQuery() {
        return search;
    }

    public void setSearchQuery(String search) {
        this.search = search;
    }   
}